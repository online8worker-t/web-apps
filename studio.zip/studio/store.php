<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Services<?php echo $appName; ?></title>
    <style>
        nav .btn-1:nth-child(4) {
            border-bottom: 4px solid var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem;
        }

        nav .btn-1:nth-child(4) svg {
            fill: var(--primary) !important;
        }
    </style>
</head>

<body>

    <?php include_once('header.php') ?>

    <section class="posts">
        <div class="container-5">
            <h2>Services</h2>
        </div>
        <div class="container-4">
            <a target="_blank" href="https://wa.me/+94765395434?text=Web-Development" class="post">
                <h1 class="title">Web Development</h1>
                <div class="details"></div>
            </a>
            <a target="_blank" href="https://wa.me/+94765395434?text=Graphic-Design" class="post">
                <h1 class="title">Grpahic Design Solutions</h1>
                <div class="details"></div>
            </a>
            <a target="_blank" href="https://wa.me/+94765395434?text=App-Development" class="post">
                <h1 class="title">App Development</h1>
                <div class="details"></div>
            </a>
            <a target="_blank" href="https://wa.me/+94765395434?text=UI-UX" class="post">
                <h1 class="title">UI/UX</h1>
                <div class="details"></div>
            </a>
            <a target="_blank" href="https://wa.me/+94765395434?text=Custom-Software" class="post">
                <h1 class="title">Custom Software</h1>
                <div class="details"></div>
            </a>
            <a target="_blank" href="https://wa.me/+94765395434?text=Music-Production" class="post">
                <h1 class="title">Music Production</h1>
                <div class="details"></div>
            </a>
            <a target="_blank" href="https://gdoop.us/@ravindu?from=studio" class="post portfolio">
                <h1 class="title">Portfolio</h1>
                <div class="details"></div>
            </a>
        </div>
    </section>

</body>

</html>