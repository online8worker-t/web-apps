<?php
$v = "?v=1.20";
$appName = " - Gdoop";
?>

<link rel="shortcut icon" href="favicon.png"> 
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description"
    content="Gdoop Studio - Web Development, Graphic Design, and Video Editing Services. Get stunning digital solutions tailored for your business.">
<meta name="keywords"
    content="web development, graphic design, video editing, branding, UI/UX design, Gdoop Studio">
<meta name="author" content="Gdoop Studio">

<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">

<!-- Open Graph (OG) for Social Media Sharing -->
<meta property="og:title" content="Bringing your ideas to life with expert web, design & video solutions.">
<meta property="og:description"
    content="Websites, Web Application Tools, Mobile Apps, Software Tools, Music, Video, Animations, 3D Models, House Plans, Blogs, More ...">
<meta property="og:image" content="https://gdoop.us/assets/preview.png">
<!-- Add your preview image URL -->
<meta property="og:url" content="https://www.gdoop.us/studio">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Gdoop Studio">

<!-- Schema Markup (Structured Data for Search Engines) -->
<script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": "Gdoop Studio",
        "url": "https://www.gdoop.us/studio",
        "description": "Bringing your ideas to life with expert web, design & video solutions.",
        "image": "https://gdoop.us/assets/preview.png",
        "sameAs": [
            "https://www.facebook.com/yourpage",
            "https://twitter.com/yourtwitterhandle",
            "https://www.linkedin.com/company/gdoop"
        ]
    }
</script>

<!-- Robots Meta (Indexing Instructions for Search Engines) -->
<meta name="robots" content="index, follow">

<!-- fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link
    href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
    rel="stylesheet">

<link rel="stylesheet" href="./assets/fonts.css">
<link rel="stylesheet" href="index.css<?php echo $v; ?>">
<script src="index.js<?php echo $v; ?>" defer></script>