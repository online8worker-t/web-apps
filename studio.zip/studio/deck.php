<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Let's Talk<?php echo $appName; ?></title>
    <style>
        nav .btn-1:nth-child(5) {
            border-bottom: 4px solid var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem;
        }

        nav .btn-1:nth-child(5) svg {
            fill: var(--primary) !important;
        }
    </style>
</head>

<body>

    <?php include_once('header.php') ?>

    <section class="posts">
        <div class="container-6">
        <div class="post-3">
                <h1 class="title">Join our community.</h1>
                <div class="details">
                    <p>For:</p>
                    <p>- News</p>
                    <p>- Music</p>
                    <p>- Movies & Series</p>
                    <p>- Tech info</p>
                    <p>- Jobs</p>
                    <br>
                    <div class="follow-us">
                        <a href="https://chat.whatsapp.com/I79kc2kNXMGH6LgsWp4IGH">WhatsApp Community</a>
                        <a href="https://whatsapp.com/channel/0029VaoEzwn8fewtEL1B0D3l">WhatsApp Channel</a>
                        <a href="https://fb.com/61566351922125">Facebook</a>
                    </div>
                </div>
                
            </div>
        </div>
    </section>

</body>

</html>