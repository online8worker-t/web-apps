<section class="loader">
    <!-- <img src="./favicon.png" alt=""> -->
     <h1>G.</h1>
</section>