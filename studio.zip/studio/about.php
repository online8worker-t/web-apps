<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>About<?php echo $appName; ?></title>
    <style>
        nav .btn-1:nth-child(4) {
            border-bottom: 4px solid transparent;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem;
        }
    </style>
</head>

<body>

    <?php include_once('header.php') ?>

    <section class="store">
        <div class="container">
            <div class="item">
                <h1 class="title">Gdoop Studio</h1>
                <div class="details">
                    <p>We make stuff and put it on the internet.</p>
                    <br>
                    <p>Main website:</p>
                    <a href="https://gdoop.us">gdoop.us</a>
                </div>
                <div class="details">
                    <br>
                    <p>Developer & Designer:</p>
                    <p>Ravindu Madhushankha</p>
                    <p>ravindu@gdoop.us</p>
                    <br>
                    <p>Contact:</p>
                    <p>info@gdoop.us</p>
                    <p>+94765395434</p>
                    <br>
                    <div class="follow-us">
                        <a href="https://web.facebook.com/profile.php?id=61557345310702">Facebook</a>
                        <a href="https://wa.me/+94765395434">Whatsapp</a>
                        <a href="https://github.com/mounter7">Github</a>
                      </div>
                      <br>
                      <div class="follow-us">
                        <a href="https://linkedin.com/in/ravindu-madhushankha">Linkedin</a>
                        <a href="https://x.com/ravindu__M">Twitter</a>
                        <a href="https://youtube.com/RavinduMadhushankha">Youtube</a>
                        </div>
                    </div>
                    <br>
                    <br>
                    <p>&copy; 2022 - <?php echo date('Y'); ?> Gdoop. All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </section>

</body>

</html>