<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Media<?php echo $appName; ?></title>
    <style>
        nav .btn-1:nth-child(2) {
            border-bottom: 4px solid var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem;
        }

        nav .btn-1:nth-child(2) svg {
            fill: var(--primary) !important;
        }
    </style>
</head>

<body>

    <?php include_once('header.php') ?> 

    <section class="posts">
        <div class="container-5">
            <h2>Gdoop Music</h2>
        </div>
        <div class="container music">

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/3-jVUYsiyWU?si=lJDZWimvYWq1mWms" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/GYia9r4T4HA?si=jigQRjl1sUPWBWcx" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/m0CgZ7c92XE?si=SiUBZjrbY0_LGeXH" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/c_BwUlCLnKk?si=9Fqd6CX5DZZlEaGm" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/X3Z9Grx_DnA?si=XxNkZc-1InZJyPFU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/VJfPI9UcDJM?si=Ssh7KfAKuyvEehVc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/4Vmp8_-QB64?si=f8vr1VRvtvJ1Rwv3" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/4vD2jc_dfDI?si=PheZpNDuTOyQV6V0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/AvhC6BFoRMo?si=QgBbRAA2weQUstDL" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/4RSBTVYuIUU?si=8ZdvvN3U8aqysbYv" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/9e3OydBQoZk?si=vjWpXK7EcNzJ7G6Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/-ukUpQRSqqI?si=-glaKN4kU4gDIp0E" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/syHY2iGP9a8?si=hH6x2aY9I9h2eOAK" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/w8SbShQ_Gxk?si=op2t3pU_Q1guZCEJ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/3ojrOlnOuZQ?si=4-pmF-H9fYFC_xGn" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/bj7XoXAwtF4?si=-SD-1PD46jzmx8-v" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/ttNEZqPF53E?si=LZfklGFgEGwJnbJ5" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>



            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/6Y-BKpat42c?si=-n-soZ9g6tmCw1oH" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/zc7Ku2rVtTY?si=2foZUMHLM0dDwb-F" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/mvekBD-hmdU?si=076tReVoIC_VfcJT" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/_2o0iZ8Gsms?si=qFgtpaDxO4N9WY6t" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/tIRi4qe13Fs?si=QJDXg7jysrPPRTso" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/8LdhnyyHr_M?si=G17QOMqtNZaRgP63" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

            <iframe class="" width="560" height="315" src="https://www.youtube.com/embed/kd9eBaUjQmk?si=WRyca2OM87xGdVHs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>


        </div>
    </section>

</body>

</html>