<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Apps<?php echo $appName; ?></title>
    <script src="./projects/apps.js<?php echo $v; ?>" defer></script>
    <style>
        nav .btn-1:nth-child(3) {
            border-bottom: 4px solid var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem;
        }

        nav .btn-1:nth-child(3) svg {
            fill: var(--primary) !important;
        }
    </style>
</head>

<body>

    <?php include_once('header.php') ?>

    <section class="posts">
        <div class="container-5">
            <h2>Software & Tools</h2>
        </div>
        <div class="container-3" id="itemGrid">
            
        </div>
    </section>

</body>

</html>