<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Page Not Found<?php echo $appName; ?></title>
    <style>
        nav .btn-1:nth-child(5) {
            border-bottom: 4px solid transparent;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem;
        }
    </style>
</head>

<body>

    <?php include_once('header.php') ?>

    <section class="notifications">
        <div class="container">
            <h1>Page Not Found.</h1>
        </div>
    </section>

</body>

</html>