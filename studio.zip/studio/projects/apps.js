const items = [
    {
        id: "9bZkp7q19f0",
        title: "CV Maker",
        thumbnail: "./projects/apps/cv-maker.png",
        link: "https://gdoop.us/cv-maker",
        dev: "",
        date: "20-04-2025",
        description: "In this tutorial, we'll build a YouTube clone from scratch using modern web technologies. Learn how to create responsive layouts, implement a video grid, and add interactive features like a modal for video details.\n\nTimestamps:\n00:00 Introduction\n02:15 HTML Structure\n05:40 CSS Styling\n08:20 JavaScript Functionality"
    },
    {
        id: "PkZNo7MFNFg",
        title: "Link Shorter",
        thumbnail: "./projects/apps/link-shorter.png",
        link: "https://gdoop.us/l",
        dev: "",
        date: "20-04-2025",
        description: "In this tutorial, we'll build a YouTube clone from scratch using modern web technologies. Learn how to create responsive layouts, implement a video grid, and add interactive features like a modal for video details.\n\nTimestamps:\n00:00 Introduction\n02:15 HTML Structure\n05:40 CSS Styling\n08:20 JavaScript Functionality"
    },
    {
        id: "PkZNo7MFNFg",
        title: "Birthday Card Maker",
        thumbnail: "./projects/apps/bd-m-logo.png",
        link: "https://gdoop.us/bd-m",
        dev: "",
        date: "20-04-2025",
        description: "In this tutorial, we'll build a YouTube clone from scratch using modern web technologies. Learn how to create responsive layouts, implement a video grid, and add interactive features like a modal for video details.\n\nTimestamps:\n00:00 Introduction\n02:15 HTML Structure\n05:40 CSS Styling\n08:20 JavaScript Functionality"
    },
    {
        id: "PkZNo7MFNFg",
        title: "potomaz",
        thumbnail: "./projects/apps/image-gallery.png",
        link: "https://gdoop.us/image-gallery",
        dev: "",
        date: "20-04-2025",
        description: "In this tutorial, we'll build a YouTube clone from scratch using modern web technologies. Learn how to create responsive layouts, implement a video grid, and add interactive features like a modal for video details.\n\nTimestamps:\n00:00 Introduction\n02:15 HTML Structure\n05:40 CSS Styling\n08:20 JavaScript Functionality"
    },
    {
        id: "PkZNo7MFNFg",
        title: "Corica",
        thumbnail: "./projects/apps/corica-favicon.png",
        link: "https://corica.online",
        dev: "",
        date: "20-04-2025",
        description: "In this tutorial, we'll build a YouTube clone from scratch using modern web technologies. Learn how to create responsive layouts, implement a video grid, and add interactive features like a modal for video details.\n\nTimestamps:\n00:00 Introduction\n02:15 HTML Structure\n05:40 CSS Styling\n08:20 JavaScript Functionality"
    },
    {
        id: "PkZNo7MFNFg",
        title: "QR Code Generator",
        thumbnail: "./projects/apps/qr-generator.png",
        link: "https://gdoop.us/tools/qr",
        dev: "",
        date: "20-04-2025",
        description: "In this tutorial, we'll build a YouTube clone from scratch using modern web technologies. Learn how to create responsive layouts, implement a video grid, and add interactive features like a modal for video details.\n\nTimestamps:\n00:00 Introduction\n02:15 HTML Structure\n05:40 CSS Styling\n08:20 JavaScript Functionality"
    },
    {
        id: "PkZNo7MFNFg",
        title: "Typiz",
        thumbnail: "./projects/apps/typiz.png",
        link: "https://github.com/mounter7/typiz",
        dev: "",
        date: "20-04-2025",
        description: "In this tutorial, we'll build a YouTube clone from scratch using modern web technologies. Learn how to create responsive layouts, implement a video grid, and add interactive features like a modal for video details.\n\nTimestamps:\n00:00 Introduction\n02:15 HTML Structure\n05:40 CSS Styling\n08:20 JavaScript Functionality"
    },
    {
        id: "PkZNo7MFNFg",
        title: "Gdoop Studio",
        thumbnail: "./projects/apps/gdoop-studio.png",
        link: "https://gdoop.us/studio",
        dev: "",
        date: "20-04-2025",
        description: "In this tutorial, we'll build a YouTube clone from scratch using modern web technologies. Learn how to create responsive layouts, implement a video grid, and add interactive features like a modal for video details.\n\nTimestamps:\n00:00 Introduction\n02:15 HTML Structure\n05:40 CSS Styling\n08:20 JavaScript Functionality"
    },
    {
        id: "PkZNo7MFNFg",
        title: "WA Linca",
        thumbnail: "./projects/apps/wa-linca.png",
        link: "https://gdoop.us/wa",
        dev: "",
        date: "20-04-2025",
        description: "In this tutorial, we'll build a YouTube clone from scratch using modern web technologies. Learn how to create responsive layouts, implement a video grid, and add interactive features like a modal for video details.\n\nTimestamps:\n00:00 Introduction\n02:15 HTML Structure\n05:40 CSS Styling\n08:20 JavaScript Functionality"
    },
    {
        id: "PkZNo7MFNFg",
        title: "Share",
        thumbnail: "./projects/apps/gdoop-share.png",
        link: "https://gdoop.us/share",
        dev: "",
        date: "20-04-2025",
        description: "In this tutorial, we'll build a YouTube clone from scratch using modern web technologies. Learn how to create responsive layouts, implement a video grid, and add interactive features like a modal for video details.\n\nTimestamps:\n00:00 Introduction\n02:15 HTML Structure\n05:40 CSS Styling\n08:20 JavaScript Functionality"
    }
];

// DOM Elements
const itemGrid = document.getElementById('itemGrid');

// Render Videos
function renderItems() {
    itemGrid.innerHTML = '';
    items.forEach(item => {
        const itemCard = document.createElement('div');
        itemCard.className = 'post-1';
        itemCard.innerHTML = `
        <a target="blank_" href="${item.link}">        
        <img src="${item.thumbnail}" alt="${item.title}">
                    <h3>${item.title}</h3>
                    <p>${item.dev}</p>
            </a>
        `;
        //itemCard.addEventListener('click', () => openVideoModal(video));
        itemGrid.appendChild(itemCard);
    });
}

// Initialize
renderItems();