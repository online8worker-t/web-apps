<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Terms<?php echo $appName; ?></title>
    <style>
        nav .btn-1:nth-child(4) {
            border-bottom: 4px solid transparent;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem;
        }
    </style>
</head>

<body>

    <?php include_once('header.php') ?>

    <section class="store">
        <div class="container">
            <div class="item">
                
            </div>
        </div>
    </section>

</body>

</html>