const menuBtn = document.querySelector('.menu-btn')
const sidebar = document.querySelector('.sidebar')

menuBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active')
})


// Preloader
document.querySelector('.home').addEventListener('load', () => {
    document.querySelector('.loader').classList.add('hide')
});




// theme
// document.querySelector('.theme-btn').addEventListener('click', (e) => {
//     e.preventDefault();
//     document.querySelector('body').classList.toggle('dark');
// })