<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Licenses<?php echo $appName; ?></title>
</head>

<body>

    <?php include_once('header.php') ?>
    <?php include_once('loader.php') ?>
    
<main class="max-w-5xl mx-auto p-6 space-y-12">
    
    <section class="posts">
        <div class="container-2">
            
            <div class="post-2">
                <h1 class="title"></h1>
                <div class="details">

<br>Copyright Free Music For Creators
<br>
<br>How to Get the License:  
<br>Simply copy and paste the track information below into your description.
<br>
<br><a target="_blank" href="https://soundcloud.com/gdoop-music">Download Music</a>
<br>
<br>
<br>ID: GDOOPMUSIC027  
<br>Title: Gdoop - I See Everything
<br>Link: https://youtu.be/lHIU0uxlyxs 
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 12 June 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/lHIU0uxlyxs">Play</a>
<br>
<br>ID: GDOOPMUSIC025 
<br>Title: Gdoop - Negative or Positive
<br>Link: https://youtu.be/-ukUpQRSqqI
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 15 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/-ukUpQRSqqI">Play</a>
<br>
<br>ID: GDOOPMUSIC024 
<br>Title: Gdoop - Little Man
<br>Link: https://youtu.be/9e3OydBQoZk
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 12 June 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/9e3OydBQoZk">Play</a>
<br>
<br>ID: GDOOPMUSIC002  
<br>Title: Gdoop - Game of Thrones Remake
<br>Link: https://youtu.be/tIRi4qe13Fs 
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 07 Jan 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/tIRi4qe13Fs">Play</a>
<br>
<br>ID: GDOOPMUSIC003
<br>Title: Gdoop - Release  
<br>Link: https://youtu.be/syHY2iGP9a8  
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 13 Jan 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/syHY2iGP9a8">Play</a>
<br>
<br>ID: GDOOPMUSIC004  
<br>Title: Gdoop - Stress 
<br>Link: https://youtu.be/_2o0iZ8Gsms
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 11 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/_2o0iZ8Gsms">Play</a>
<br>
<br>ID: GDOOPMUSIC026  
<br>Title: Gdoop - Aaley Mal (Remake)  
<br>Link: https://youtu.be/syHY2iGP9a8  
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 15 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/syHY2iGP9a8">Play</a>
<br>
<br>ID: GDOOPMUSIC005  
<br>Title: Gdoop - Dhoom Remake 
<br>Link: https://youtu.be/mvekBD-hmdU  
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 11 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/mvekBD-hmdU">Play</a>
<br>
<br>ID: GDOOPMUSIC007 
<br>Title: Gdoop - Holiday
<br>Link: https://youtu.be/6Y-BKpat42c
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 11 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/6Y-BKpat42c">Play</a>
<br>
<br>ID: GDOOPMUSIC006
<br>Title: Gdoop - Project A05
<br>Link: https://youtu.be/zc7Ku2rVtTY
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 11 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/zc7Ku2rVtTY">Play</a>
<br>
<br>ID: GDOOPMUSIC011 
<br>Title: Gdoop - Kalki BGM Remake
<br>Link: https://youtu.be/4Vmp8_-QB64
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 11 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/4Vmp8_-QB64">Play</a>
<br>
<br>ID: GDOOPMUSIC010 
<br>Title: Gdoop - Paradise 
<br>Link: https://youtu.be/3ojrOlnOuZQ
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 11 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/3ojrOlnOuZQ">Play</a>
<br>
<br>ID: GDOOPMUSIC008 
<br>Title: Gdoop - Cross The Line 
<br>Link: https://youtu.be/3-jVUYsiyWU
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 11 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/3-jVUYsiyWU">Play</a>
<br>
<br>ID: GDOOPMUSIC012 
<br>Title: Gdoop - Read Me
<br>Link: https://youtu.be/AvhC6BFoRMo
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 11 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/AvhC6BFoRMo">Play</a>
<br>
<br>ID: GDOOPMUSIC013 
<br>Title: Gdoop - Just Relax  
<br>Link: https://youtu.be/4vD2jc_dfDI
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 11 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/4vD2jc_dfDI">Play</a>
<br>
<br>ID: GDOOPMUSIC014 
<br>Title: Gdoop - Move Up
<br>Link: https://youtu.be/GYia9r4T4HA 
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 11 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/GYia9r4T4HA">Play</a>
<br>
<br>ID: GDOOPMUSIC015 
<br>Title: Gdoop - Enough 
<br>Link: https://youtu.be/VJfPI9UcDJM 
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 11 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/VJfPI9UcDJM">Play</a>
<br>
<br>ID: GDOOPMUSIC016 
<br>Title: Gdoop - Dance on the floor 
<br>Link: https://youtu.be/bj7XoXAwtF4
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 12 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/bj7XoXAwtF4">Play</a>
<br>
<br>ID: GDOOPMUSIC017 
<br>Title: Gdoop - Ride it Remake
<br>Link: https://youtu.be/ttNEZqPF53E
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 12 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/ttNEZqPF53E">Play</a>
<br>
<br>ID: GDOOPMUSIC020 
<br>Title: Gdoop - Turbo Booster 
<br>Link: https://youtu.be/c_BwUlCLnKk
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 12 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/c_BwUlCLnKk">Play</a>
<br>
<br>ID: GDOOPMUSIC018 
<br>Title: Gdoop - Sri Lankan Traditional Vibes 
<br>Link: https://youtu.be/X3Z9Grx_DnA
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 12 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/X3Z9Grx_DnA">Play</a>
<br>
<br>ID: GDOOPMUSIC023
<br>Title: Gdoop - I am
<br>Link: https://youtu.be/w8SbShQ_Gxk
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 12 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/w8SbShQ_Gxk">Play</a>
<br>
<br>ID: GDOOPMUSIC021 
<br>Title: Gdoop - Miami 2 ibiza Remake
<br>Link: https://youtu.be/kd9eBaUjQmk
<br>Producer: Ravindu Madhushankha  
<br>Release Date: 12 May 2025  
<br>Provided by: Gdoop Studio
<br>------
<br><a target="_blank" href="https://youtu.be/kd9eBaUjQmk">Play</a>

                </div>
            </div>


        </div>
    </section>

    <style>
        nav .btn-1:nth-child(1) {
            display: none;
        }

    </style>


    <script>
        window.addEventListener('load', () => {
            document.querySelector('.loader').classList.add('hide')
        });
    </script>
</body>

</html>