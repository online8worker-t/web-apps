<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Careers<?php echo $appName; ?></title>
    <style>
        nav .btn-1:nth-child(4) {
            border-bottom: 4px solid transparent;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem;
        }
    </style>
</head>

<body>

    <?php include_once('header.php') ?>

    <section class="store">
        <div class="container">
            <div class="item">
                <h1 class="title">Join our team.</h1>
                <div class="details">
                    <p>Upload your CV to careers.gdoop.us</p>
                    <br>
                    <p><a href="https://gdoop.us">WhatsApp Community</a>
                    <p><a href="https://wa.me/+94765395434">WhatsApp Channel</a></p>
                    <p><a href="https://fb.com/61566351922125">Facebook</a></p>
                </div>
            </div>
    </section>

</body>

</html>