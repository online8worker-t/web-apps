<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Home<?php echo $appName; ?></title>
</head>

<body>

    <?php include_once('header.php') ?>
    <?php include_once('loader.php') ?>
    
<main class="max-w-5xl mx-auto p-6 space-y-12">
    
    <section class="posts">
        <div class="container-2">
            
            <div class="post-2">
                <h1 class="title">Welcome to Gdoop Studio.</h1>
                <div class="details">
                    <p>Gdoop is the digital playground, blending creativity, utility, and community. Whether you're discovering fresh music, crafting polished documents, boosting your digital presence, or launching creative projects — Gdoop makes it all easy.</p>
                </div>
            </div>
        
            
            <div class="post-2">
                <h1 class="title">Music</h1>
                <div class="details">
                    <p>We've released our new music tracks on youtube. Enjoy!</p>
                    <a target="_blank" href="https://youtube.com/@GdoopStudio">Gdoop Studio Youtube Channel.</a>
                </div>
                <img src="./assets/thumb-19.png" alt="gdoop studio music, ravindu madhushankha.">
            </div>


        </div>
    </section>

    <style>
        nav .btn-1:nth-child(1) {
            border-bottom: 4px solid var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem;
        }

        nav .btn-1:nth-child(1) svg {
            fill: var(--primary) !important;
        }
    </style>


    <script>
        window.addEventListener('load', () => {
            document.querySelector('.loader').classList.add('hide')
        });
    </script>
</body>

</html>