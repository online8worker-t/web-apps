<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="shortcut icon" href="favicon.png">
    <link rel="apple-touch-icon" href="favicon.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>

    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <script src="./index.js" defer></script>

    <style>
        *,
        ::after,
        ::before {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-size: 16px;
        }

        body {
            background: #f5f5f5;
        }

        a {
            text-decoration: none;
            color: #000;
        }

        a:hover {
            text-decoration: underline;
        }

        .contact {
            padding: 2rem 0;
        }

        .form-1 {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            max-width: 600px;
            margin: 0 auto;
            align-items: center;
            background: #fff;
            padding: 1rem;
        }

        input[type="text"],
        select,
        textarea {
            padding: 0.5rem;
            border-radius: 5px;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-size: 1em;
            width: 100%;
            border: none;
            background: #eee;
        }

        textarea {
            resize: vertical;
        }

        .btn {
            background: #000;
            color: #fff;
            padding: 0.5rem 2rem;
            cursor: pointer;
            outline: none;
            border: none;
            border-radius: 5px;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-size: 1em;
        }

        h2 {
            font-size: 1.2em;
        }

        .form-1>p,
        .form-1 b {
            font-size: 1.1em;
        }

        .contact-info {
            text-align: center;
            color: 454545;
        }

        .contact-info p {
            font-size: 1em;
        }

        .profile {
            width: 100px;
            height: 100px;
            border-radius: 50%;
        }

        /* loader */
        .loader {
            width: 100%;
            height: 100%;
            background: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 5;
            overflow: hidden;
        }

        .loader h2 {
            font-size: 2rem;
            font-weight: bold;
            animation: 2s opacity infinite;
        }

        @keyframes opacity {
            0% {
                opacity: 1;
            }

            50% {
                opacity: 0.3;
            }

            100% {
                opacity: 1;
            }
        }
    </style>
</head>

<body>
    <section class="contact">
        <form class="form-1">
            <img class="profile" src="./favicon.png" alt="">
            <p>Hello! <b>I’m Ravindu Madhushankha,</b> a passionate <b>software developer</b> and <b>designer</b> from <b>Sri Lanka.</b> With <b>experience in web development, UI/UX design, software development, music production, video editing, graphic design, and house planing.</b> I love building innovative and user-friendly digital solutions.</p>
            <br>
            <h2>Contact Me</h2>
            <input type="text" name="name" placeholder="Your name">
            <input type="text" name="e-wa" placeholder="Your Email | WhatsApp">
            <select name="bubget" id="">
                <option value="none">Your Budget</option>
                <option value="5-20">$5 - $20</option>
                <option value="20-50">$20 - $50</option>
                <option value="50-100">$50 - $100</option>
                <option value="100-200">$100 - $200</option>
                <option value="200-500">$200 - $500</option>
                <option value="Let's Talk">Let's Talk</option>
            </select>
            <textarea name="idea" rows="5" id="" placeholder="More info ... "></textarea>
            <input type="submit" class="btn" value="Send">
            <p id="responseMessage" class="mt-3"></p>
            <div class="contact-info">
                <p>ravindu@gdoop.us | +94765395434</p>
                <br>
                <a target="_blank" href="https://web.facebook.com/profile.php?id=61557345310702">Facebook</a> |
                <a target="_blank" href="https://wa.me/+94765395434">WhatsApp</a> |
                <a target="_blank" href="https://www.youtube.com/@RavinduMadhushankha">Youtube</a> |
                <a target="_blank" href="https://www.linkedin.com/in/ravindu-madhushankha">LinkedIn</a> |
                <a target="_blank" href="https://www.github.com/mounter7">Github</a>
                <p>Ravindu Madhushankha</p>
            </div>
        </form>
    </section>

    <div class="loader">
        <h2>Ravindu.</h2>
    </div>

</body>


<script>
    document.querySelector(".form-1").addEventListener("submit", async function(event) {
        event.preventDefault();

        let formData = new FormData(this);
        let responseMessage = document.getElementById("responseMessage");

        try {
            let response = await fetch("api/contact.php", {
                method: "POST",
                body: formData
            });

            let result = await response.json();

            if (result.success) {
                responseMessage.style.color = "green";
                this.reset(); // Clear form after successful submission
            } else {
                responseMessage.style.color = "red";
            }

            responseMessage.textContent = result.message;
        } catch (error) {
            responseMessage.style.color = "red";
            responseMessage.textContent = "An error occurred. Please try again.";
        }
    });
</script>

</html>