<?php $description = "I Create & Share
Innovative Projects on the Internet"; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="shortcut icon" href="favicon.png">
    <link rel="apple-touch-icon" href="favicon.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ravindu Madhushankha | <?php echo $description; ?></title>
    <link rel="stylesheet" href="index.css?v=1.6">
    <script src="./index.js?v=1.6" defer></script>

    <meta name="description" content="<?php echo $description; ?>.">
    <meta name="keywords"
        content="Ravindu, Madhushankha, Gdoop Studio, Copyrights free images, qr code generator, hnde report helper, hnde cover page maker, typiz, wa linca, corica, gdoop studio, birthday card maker, uni triangle, Gdoop CV Maker, Resume Builder, Online CV, Free Resume Creator, Professional CV, Job Application, Resume Templates">
    <meta name="author" content="Ravindu Madhushankha">

    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">

    <!-- Open Graph (OG) for Social Media Sharing -->
    <meta property="og:title" content="<?php echo $description; ?>.">
    <meta property="og:description" content="Websites, Web Application Tools, Mobile Apps, Software Tools, Music, Video, Animations, 3D Models, House Plans, Blogs, More ...">
    <meta property="og:image" content="https://gdoop.us/@ravindu/assets/preview.jpg">
    <!-- Add your preview image URL -->
    <meta property="og:url" content="https://www.gdoop.us/@ravindu">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Ravindu Madhushankha">

    <!-- Schema Markup (Structured Data for Search Engines) -->
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": "Gdoop CV Maker",
            "url": "https://www.gdoop.us/@ravindu",
            "description": "I Create & Share
            Innovative Projects on the Internet.
            ",
            "image": "https://gdoop.us/@ravindu/assets/preview.jpg",
            "sameAs": [
                "https://www.facebook.com/yourpage",
                "https://twitter.com/yourtwitterhandle",
                "https://www.linkedin.com/company/gdoop"
            ]
        }
    </script>

    <!-- Robots Meta (Indexing Instructions for Search Engines) -->
    <meta name="robots" content="index, follow">

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="./assets/fonts.css">
</head>

<body>

    <section>
        <div class="section-0">
            <div class="container">
                <header>
                    <a href="https://gdoop.us/@ravindu" class="logo">Ravindu.</a>
                    <a target="_blank" href="contact"><img src="./assets/call-icon.png" class="call-icon"
                            alt="gdoop contact"></a>
                </header>
                <div class="item content">
                    <div class="apps"></div>
                    <h1>I <span>Create</span> & <span>Share</span><br> Innovative Projects on the <span>Internet</span>.</h1>
                    <br>
                    <h2>Got a new idea?</h2>
                    <a target="_blank" href="contact" class="btn">Let's talk</a>
                </div>

                <h2 class="title">Recent Free Applications</h2>

                <div class="item tags">

                    <a target="_blank" href="https://gdoop.us/cv-maker" class="tag">
                        <img src="./assets/1.png" alt="gdoop cv maker">
                        <p>CV Maker</p>
                    </a>
                    <a target="_blank" href="https://gdoop.us/uni-triangle" class="tag">
                        <img src="https://gdoop.us/hnde-triangle/favicon.png" alt="gdoop cv maker">
                        <p>HNDE Triangle</p>
                    </a>
                    <a target="_blank" href="https://gdoop.us/image-gallery" class="tag">
                        <img src="./assets/3.png" alt="gdoop cv maker">
                        <p>Image Gallery</p>
                    </a>
                    <a target="_blank" href="https://gdoop.us/bd-m" class="tag">
                        <img src="./assets/4.png" alt="gdoop cv maker">
                        <p>Birthday Card Maker</p>
                    </a>
                    <a target="_blank" href="https://gdoop.us/l" class="tag">
                        <img src="./assets/5.png" alt="gdoop cv maker">
                        <p>Link Shorter</p>
                    </a>
                    <a target="_blank" href="https://gdoop.us/qr/" class="tag">
                        <img src="./assets/6.png" alt="gdoop cv maker">
                        <p>QR Generator</p>
                    </a>
                    <a target="_blank" href="https://gdoop.us/hnde-triangle/rhv3?from=gdoop" class="tag">
                        <img src="./assets/7.png" alt="gdoop cv maker">
                        <p>HNDE Report Helper</p>
                    </a>
                    <a target="_blank" href="https://github.com/mounter7/typiz" class="tag">
                        <img src="./assets/8.png" alt="gdoop cv maker">
                        <p>Typiz</p>
                    </a>
                    <a target="_blank" href="https://gdoop.us/wa" class="tag">
                        <img src="./assets/9.png" alt="gdoop cv maker">
                        <p>Custom WhatsApp Link Generator</p>
                    </a>
                    <a target="_blank" href="https://corica.online/" class="tag">
                        <img src="./assets/10.png" alt="gdoop cv maker">
                        <p>Corica</p>
                    </a>
                    <a target="_blank" href="https://gdoop.us/studio" class="tag">
                        <img src="./assets/11.png" alt="gdoop cv maker">
                        <p>Gdoop Studio | Music/Video/Doc</p>
                    </a>

                </div>

                <div class="feedback">
                    <h2>Anyway, what do you think about these tools?</h2>
                    <a class="btn-1" target="_blank" href="feedback">Say Something</a>
                </div>

            </div>

            <h2 class="title">What Users Say</h2>

            <div class="item say-item">
                <div class="says">
                    <div class="say">
                        <p>Very useful tools for us. All the best. ❤️ </p>
                        <p>Hasala Dilshan Rathnayake</p>
                    </div>
                    <div class="say">
                        <p>Machn. Meka godaak watinawa bn. Meka nathan mata loku welawk spend krnn wenw cover page ekk hadanna. Eth me generator hinda mn print out ganna book shop ekat gihillath generate krla tiyenw. Supiria machn. I wish you All the very best. Digatama karagena yaman. ❤️</p>
                        <p>Hisbullah</p>
                    </div>
                    <div class="say">
                        <p>Appreciate your work.</p>
                        <p>Thusitha</p>
                    </div>
                    <div class="say">
                        <p>This is really a good one... Have been very convenient and effective throughout the academics. Really a life saver.. And easy peacy 😍</p>
                        <p>Savie</p>
                    </div>
                    <div class="say">
                        <p>It's really helpful to us aiya. Cause all students of the HNDE start their assignments before 3 or 2 submission date. So I hope u write new era with ur amazing skills. Thank you brother and Good luck.</p>
                        <p>Eshini Pabodha</p>
                    </div>
                    <div class="say">
                        <p>That is a very good job.</p>
                        <p>G.R.Palihakkara</p>
                    </div>
                    <div class="say">
                        <p>Excellent work.</p>
                        <p>P.M. Rathnasooriya</p>
                    </div>
                </div>
            </div>

            <div class="item about-us">
                <div class="content">
                    <h2>About Me</h2>
                    <p>Hello! <b>I’m Ravindu Madhushankha,</b> a passionate <b>software developer</b> and <b>designer</b> from <b>Sri Lanka.</b> With <b>experience in web development, UI/UX design, software development, music production, video editing, graphic design, and house planing.</b> I love building innovative and user-friendly digital solutions. I am blending my analytical mindset with creativity to <b>solve real-world problems through technology. Over the years, I have developed various projects.</b><br><br>
                        Apart from coding, <b>I have a deep passion for music production, primarily creating instrumental track.</b> I also enjoy watching movies, gaming, and listening to EDM music.<br><br>
                        Whether it’s developing web applications, designing interfaces, or producing music, I strive for excellence and creativity in everything I do.
                    </p><br>
                    <div class="contact-info">
                        <p><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4-8 5-8-5V6l8 5 8-5v2z"/></svg> <span> ravindu@gdoop.us</span></p>
                        <p><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"><path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56a.977.977 0 0 0-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z"/></svg> <span> +94765395434</span></p>
                        <br>
                        <a target="_blank" href="https://web.facebook.com/profile.php?id=61557345310702">Facebook</a> |
                        <a target="_blank" href="https://wa.me/+94765395434">WhatsApp</a> |
                        <a target="_blank" href="https://www.youtube.com/@RavinduMadhushankha">Youtube</a> |
                        <a target="_blank" href="https://www.linkedin.com/in/ravindu-madhushankha">LinkedIn</a> |
                        <a target="_blank" href="https://www.github.com/mounter7">Github</a>
                    </div>
                </div>
                <img src="./assets/preview.jpg?v=1.1" alt="Ravindu Madhushankha. RCC. HNDE. Software Engineer, Civil Engineer. Designer. Developer.">
            </div>

            <hr>

            <div class="section-0 services">
                <div class="container">
                    <h2 class="title">Services</h2>

                    <div class="item tags make">

                        <a target="_blank" href="https://gdoop.us/studio/apps" class="tag">Web Application Development</a>
                        <a target="_blank" href="https://drive.google.com/file/d/1bZCftviWDO3iL8SQizMJGAHGs4XDV6am/view?usp=sharing" class="tag">UI/UX</a>
                        <a target="_blank" href="https://gdoop.us/studio/apps" class="tag">Custom Software Development</a>
                        <a target="_blank" href="https://youtube.com/@GdoopStudio" class="tag">Music Production</a>
                        <a target="_blank" href="https://youtube.com/@GdoopStudio" class="tag">Video Editing</a>
                        <a target="_blank" href="https://drive.google.com/file/d/1bZCftviWDO3iL8SQizMJGAHGs4XDV6am/view?usp=sharing" class="tag">Graphic Design</a>

                    </div>

                    <div class="order">
                        <a target="_blank" href="contact" class="btn">Place an Order</a>
                    </div>
                </div>
            </div>

            <h2 class="title">Projects Delivered for Clients</h2>

            <div class="item portfolio-item">
                <div class="portfolios">
                    <div class="portfolio">
                        <img src="./portfolio/8.png" alt="">
                        <p>WEB | UI/UX</p>
                    </div>
                    <!--<div class="portfolio">-->
                    <!--    <iframe width="560" height="315" src="https://www.youtube.com/embed/LX42b5Lvz1w?si=CaP3pQ4pebNNz4cz" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>-->
                    <!--    <p>Music | EDM</p>-->
                    <!--</div>-->
                    <!--<div class="portfolio">-->
                    <!--    <iframe width="560" height="315" src="https://www.youtube.com/embed/9e3OydBQoZk?si=P-9k37bdaGm-dgfh" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>-->
                    <!--    <p>Music | EDM</p>-->
                    <!--</div>-->
                    <div class="portfolio">
                        <img src="./portfolio/3.png" alt="">
                        <p>LOGO | BRANDING</p>
                    </div>
                    <div class="portfolio">
                        <img src="./portfolio/4.png" alt="">
                        <p>GRAPHIC | LOGO</p>
                    </div>
                    <div class="portfolio">
                        <img src="./portfolio/5.png" alt="">
                        <p>WEB | UI/UX</p>
                    </div>
                    <div class="portfolio">
                        <img src="./portfolio/6.png" alt="">
                        <p>GRAPHIC | POST</p>
                    </div>
                    <div class="portfolio">
                        <img src="./portfolio/7.png" alt="">
                        <p>GRAPHIC | LOGO</p>
                    </div>
                    <div class="portfolio">
                        <img src="./portfolio/10.png" alt="">
                        <p>GRAPHIC | POST</p>
                    </div>
                    <div class="portfolio">
                        <img src="./portfolio/11.png" alt="">
                        <p>GRAPHIC | RESUME</p>
                    </div>
                    <div class="portfolio">
                        <img src="./portfolio/12.png" alt="">
                        <p>WEB | APP | UI/UX | API</p>
                    </div>
                    <div class="portfolio">
                        <img src="./portfolio/13.png" alt="">
                        <p>WEB | UI/UX</p>
                    </div>
                </div>
            </div>


        </div>

        <div class="item copyrights">
            <p>&copy;<?php echo date('Y'); ?> Ravindu Madhushankha.
            </p>
        </div>



    </section>

    <div class="loader">
        <h2>Ravindu.</h2>
    </div>

</body>

</html>