<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="shortcut icon" href="favicon.png">
    <link rel="apple-touch-icon" href="favicon.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>

    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">

    <style>
        *,
        ::after,
        ::before {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-size: 16px;
        }

        a {
            text-decoration: none;
            color: #000;
        }
        a:hover {
            text-decoration: underline;
        }

        .contact {
            padding: 4rem 1rem;
        }

        .form-1 {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            max-width: 600px;
            margin: 0 auto;
            align-items: center;
        }

        input[type="text"],
        select,
        textarea {
            padding: 0.5rem;
            border-radius: 5px;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-size: 1em;
            width: 100%;
            border: none;
            background: #eee;
        }

        textarea {
            resize: vertical;
        }

        .btn {
            background: #000;
            color: #fff;
            padding: 0.5rem 2rem;
            cursor: pointer;
            outline: none;
            border: none;
            border-radius: 5px;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-size: 1em;
        }

        .contact-info {
            text-align: center;
            color: 454545;
        }

        .contact-info p {
            font-size: 1em;
        }
    </style>
</head>

<body>
    <section class="contact">
        <form class="form-1">
            <p>What do you think about these tools?</p>
            <select name="tool" id="tools"></select>
            <input type="text" name="name" placeholder="Your name">
            <select name="rate" id="">
                <option value="Excellent">Excellent</option>
                <option value="Very Good">Very Good</option>
                <option value="Good">Good</option>
                <option value="Bad">Bad</option>
                <option value="Very Bad">Very Bad</option>
            </select>
            <textarea name="feedback" rows="5" id="" placeholder="So, what do you think?"></textarea>
            <input type="submit" class="btn" value="Send">
            <p id="responseMessage" class="mt-3"></p>
            <div class="contact-info" style="display:flex; gap: 1rem; align-items:center; flex-direction: column;">
                <p>ravindu@gdoop.us | +94765395434</p>
                <div>
                <div class="contact-info">
                <a target="_blank" href="https://web.facebook.com/profile.php?id=61557345310702">Facebook</a> |
                <a target="_blank" href="https://wa.me/+94765395434">WhatsApp</a> |
                <a target="_blank" href="https://www.youtube.com/@RavinduMadhushankha">Youtube</a> |
                <a target="_blank" href="https://www.linkedin.com/in/ravindu-madhushankha">LinkedIn</a> |
                <a target="_blank" href="https://www.github.com/mounter7">Github</a>
                <br>
                <a target="_blank" href="https://www.gdoop.us/@ravindu">Ravindu Madhushankha</a>
            </div>
        </form>
    </section>
</body>


<script>
    fetch('api/tools.txt')
        .then(response => response.text())
        .then(data => {
            let tools = data.split("\n").filter(tool => tool.trim() !== ""); // Split lines & remove empty ones
            let select = document.getElementById("tools");

            tools.forEach(tool => {
                let option = document.createElement("option");
                option.value = tool.trim();
                option.textContent = tool.trim();
                select.appendChild(option);
            });
        })
        .catch(error => console.error("Error loading tools:", error));

    // ========================================

    document.querySelector(".form-1").addEventListener("submit", async function(event) {
        event.preventDefault();

        let formData = new FormData(this);
        let responseMessage = document.getElementById("responseMessage");

        try {
            let response = await fetch("api/feedback.php", {
                method: "POST",
                body: formData
            });

            let result = await response.json();

            if (result.success) {
                responseMessage.style.color = "green";
                this.reset(); // Clear form after successful submission
            } else {
                responseMessage.style.color = "red";
            }

            responseMessage.textContent = result.message;
        } catch (error) {
            responseMessage.style.color = "red";
            responseMessage.textContent = "An error occurred. Please try again.";
        }
    });
</script>

</html>