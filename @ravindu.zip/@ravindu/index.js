// Preloader
window.addEventListener("load", function () {
    this.setTimeout(() => {
        document.querySelector(".loader").style.display = "none";
    }, 1000)
});


window.addEventListener("load", function () {
    // Check if the page has already been reloaded
    if (!sessionStorage.getItem("cacheCleared")) {
        
        // Clear Local Storage
        localStorage.clear();

        // Clear Session Storage (Except the reload flag)
        sessionStorage.clear();
        sessionStorage.setItem("cacheCleared", "true");

        // Clear Cookies
        document.cookie.split(";").forEach(function (c) {
            document.cookie = c
                .replace(/^ +/, "")
                .replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
        });

        // Reload Page
        location.reload(true);
    }
});
