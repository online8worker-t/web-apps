<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = htmlspecialchars(trim($_POST["name"]));
    $email = trim($_POST["e-wa"]);
    $budget = $_POST["bubget"];
    $message = htmlspecialchars(trim($_POST["idea"]));
    $time = date('d-M-Y');

    if (!$name || !$email || !$message) {
        echo json_encode(["success" => false, "message" => "All fields are required."]);
        exit;
    }

    // Format message to store in the text file
    $entry = "Name: $name\nEmail: $email\nBudget: $budget\nMessage:\n$message\n$time\n----------------------\n";

    // Save to a text file
    $file = "messages.txt";
    if (file_put_contents($file, $entry, FILE_APPEND | LOCK_EX)) {
        echo json_encode(["success" => true, "message" => "Message sent successfully!"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to send message."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request."]);
}
?>
