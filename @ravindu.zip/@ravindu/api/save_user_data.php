<?php
$data = json_decode(file_get_contents('php://input'), true);

// Get IP Address
$ip = $_SERVER['REMOTE_ADDR'];
$timestamp = date("Y-m-d H:i:s");

if ($data) {
    $entry = "Timestamp: $timestamp\n";
    $entry .= "IP Address: $ip\n";
    $entry .= "Latitude: " . ($data['latitude'] ?? 'N/A') . "\n";
    $entry .= "Longitude: " . ($data['longitude'] ?? 'N/A') . "\n";
    $entry .= "User Agent: " . ($data['userAgent'] ?? 'N/A') . "\n";
    $entry .= "Platform: " . ($data['platform'] ?? 'N/A') . "\n";
    $entry .= "Language: " . ($data['language'] ?? 'N/A') . "\n";
    $entry .= "Screen Size: " . ($data['screenWidth'] ?? 'N/A') . "x" . ($data['screenHeight'] ?? 'N/A') . "\n";
    $entry .= "Timezone: " . ($data['timezone'] ?? 'N/A') . "\n";
    $entry .= "--------------------------\n";

    file_put_contents("user_data.txt", $entry, FILE_APPEND);
    echo "User data saved successfully.";
} else {
    echo "Invalid data.";
}
?>