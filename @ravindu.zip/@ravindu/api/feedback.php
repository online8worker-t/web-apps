<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $tool = trim($_POST["tool"]);
    $name = htmlspecialchars(trim($_POST["name"]));
    $rate = $_POST["rate"];
    $feedback = htmlspecialchars(trim($_POST["feedback"]));
    $time = date('d-M-Y');

    if (!$tool || !$name || !$rate) {
        echo json_encode(["success" => false, "message" => "All fields are required."]);
        exit;
    }

    // Format message to store in the text file
    $entry = "Tool: $tool\nName: $name\nRate:$rate\nFeedback:\n$feedback\n$time\n----------------------\n";

    // Save to a text file
    $file = "feedback.txt";
    if (file_put_contents($file, $entry, FILE_APPEND | LOCK_EX)) {
        echo json_encode(["success" => true, "message" => "Feedback sent successfully!"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to send message."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request."]);
}
?>
