<section class="login active">
    <div class="container">
        <img class="logo" style="border-radius: 50%;" src="favicon.png" alt="main logo">
        <div class="item">
            
        </div>
        <div class="by">
            <p>From</p>
            <h1>Gdoop Studio.</h1>
        </div>
    </div>
</section>