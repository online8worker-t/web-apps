<section id="section-0">
    <div class="container">

        <form class="form-1" action="generate" method="post" enctype="multipart/form-data">

            <div class="expand">
                <div class="item theme">
                    <div class="title">
                        <input type="text" value="Appearance" disabled>
                        <div class="dropdown"></div>
                    </div>
                    <ul>
                        <li>
                            <p>Font</p>
                            <select name="font" id="">
                                <option value="serif">Times New Romans</option>
                                <option value="sans-serif">Helvetica</option>
                                <option value="courier">Courier</option>
                            </select>
                            <p>Font colour</p>
                            <input type="color" name="color-1" value="#000000">
                            <p>Page background colour</p>
                            <input type="color" name="color-2" value="#ffffff">
                            <p>Title font colour</p>
                            <input type="color" name="color-3" value="#000000">
                            <p>Title background colour</p>
                            <input type="color" name="color-4" value="#ffffff">
                            <p>Border bottom colour of title</p>
                            <input type="color" name="color-9" value="#e70045">
                            <p>Border height</p>
                            <input type="number" name="border-height" value="1">
                            <br>
                            <p>Border radius of title</p>
                            <p>Border top left</p>
                            <input type="number" name="color-5" value="0">
                            <p>Border top right</p>
                            <input type="number" name="color-6" value="0">
                            <p>Border bottom right</p>
                            <input type="number" name="color-7" value="0">
                            <p>Border bottom left</p>
                            <input type="number" name="color-8" value="0">
                        </li>
                    </ul>
                </div>
            </div>

            <div class="expand">
                <div class="item">
                    <div class="title personal">
                        <input type="text" name="personal" value="Personal" disabled>
                        <div class="dropdown"></div>
                    </div>
                    <ul>
                        <li>
                            <input type="text" name="personal-1" placeholder="Name">
                            <input type="text" name="personal-2" placeholder="School Leaver/Engineer/Doctor/Designer/Developer">
                            <input type="text" name="personal-3" placeholder="Location/Address">
                            <input type="text" name="personal-4" placeholder="Mobile number">
                            <textarea name="personal-t-1" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <label for="file">Upload profile picture (width: 164px, height: 164px, max size: 300kb)</label>
                            <div class="btn-5 remove-img-btn">Remove profile picture</div>
                            <input id="file" type="file" name="image" style="display: none;">
                            <br>
                            <a class="btn-2" target="_blank" href="https://gdoop.us/image-resizer/">Reduce image size</a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="expand">
                <div class="item">
                    <div class="title">
                        <input type="text" name="objective" value="Profile Summary">
                        <div class="dropdown"></div>
                    </div>
                    <ul>
                        <li>
                            <textarea name="objective-1" id="" placeholder="Highly motivated and detail-oriented [Your Profession] with a strong background in ..."></textarea>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="expand">
                <div class="item">
                    <div class="title">
                        <input type="text" name="experience" value="Experience">
                        <div class="dropdown"></div>
                    </div>
                    <ul>
                        <li>
                            <input type="text" name="experience-1" placeholder="Experience 1">
                            <textarea name="experience-t-1" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="experience-2" placeholder="Experience 2">
                            <textarea name="experience-t-2" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="experience-3" placeholder="Experience 3">
                            <textarea name="experience-t-3" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="experience-4" placeholder="Experience 4">
                            <textarea name="experience-t-4" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="experience-5" placeholder="Experience 5">
                            <textarea name="experience-t-5" placeholder="More info" id=""></textarea>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="expand">
                <div class="item">
                    <div class="title">
                        <input type="text" name="education" value="Education">
                        <div class="dropdown"></div>
                    </div>
                    <ul>
                        <li>
                            <input type="text" name="education-1" placeholder="Education 1">
                            <textarea name="education-t-1" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="education-2" placeholder="Education 2">
                            <textarea name="education-t-2" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="education-3" placeholder="Education 3">
                            <textarea name="education-t-3" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="education-4" placeholder="Education 4">
                            <textarea name="education-t-4" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="education-5" placeholder="Education 5">
                            <textarea name="education-t-5" placeholder="More info" id=""></textarea>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="expand">
                <div class="item">
                    <div class="title">
                        <input type="text" name="projects" value="Projects">
                        <div class="dropdown"></div>
                    </div>
                    <ul>
                        <li>
                            <input type="text" name="projects-1" placeholder="Project 1">
                            <textarea name="projects-t-1" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="projects-2" placeholder="Project 2">
                            <textarea name="projects-t-2" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="projects-3" placeholder="Project 3">
                            <textarea name="projects-t-3" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="projects-4" placeholder="Project 4">
                            <textarea name="projects-t-4" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="projects-5" placeholder="Project 5">
                            <textarea name="projects-t-5" placeholder="More info" id=""></textarea>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="expand">
                <div class="item">
                    <div class="title">
                        <input type="text" name="technical-skills" value="Technical Skills">
                        <div class="dropdown"></div>
                    </div>
                    <ul>
                        <li>
                            <input type="text" name="technical-skills-1" placeholder="Technical Skill 1">
                            <input type="text" name="technical-skills-2" placeholder="Technical Skill 2">
                            <input type="text" name="technical-skills-3" placeholder="Technical Skill 3">
                            <input type="text" name="technical-skills-4" placeholder="Technical Skill 4">
                            <input type="text" name="technical-skills-5" placeholder="Technical Skill 5">
                            <input type="text" name="technical-skills-6" placeholder="Technical Skill 6">
                            <input type="text" name="technical-skills-7" placeholder="Technical Skill 7">
                            <input type="text" name="technical-skills-8" placeholder="Technical Skill 8">
                            <input type="text" name="technical-skills-9" placeholder="Technical Skill 9">
                            <input type="text" name="technical-skills-10" placeholder="Technical Skill 10">
                        </li>
                    </ul>
                </div>
            </div>

            <div class="expand">
                <div class="item">
                    <div class="title">
                        <input type="text" name="personal-skills" value="Personal Skills">
                        <div class="dropdown"></div>
                    </div>
                    <ul>
                        <li>
                            <input type="text" name="personal-slkils-1" placeholder="Personal Skill 1">
                            <input type="text" name="personal-skills-2" placeholder="Personal Skill 2">
                            <input type="text" name="personal-skills-3" placeholder="Personal Skill 3">
                            <input type="text" name="personal-skills-4" placeholder="Personal Skill 4">
                            <input type="text" name="personal-skills-5" placeholder="Personal Skill 5">
                            <input type="text" name="personal-skills-6" placeholder="Personal Skill 6">
                            <input type="text" name="personal-skills-7" placeholder="Personal Skill 7">
                            <input type="text" name="personal-skills-8" placeholder="Personal Skill 8">
                            <input type="text" name="personal-skills-9" placeholder="Personal Skill 9">
                            <input type="text" name="personal-skills-10" placeholder="Personal Skill 10">
                        </li>
                    </ul>
                </div>
            </div>

            <div class="expand">
                <div class="item">
                    <div class="title">
                        <input type="text" name="language" value="Languages">
                        <div class="dropdown"></div>
                    </div>
                    <ul>
                        <li>
                            <input type="text" name="language-1" placeholder="Language 1">
                            <input type="text" name="language-2" placeholder="Language 2">
                            <input type="text" name="language-3" placeholder="Language 2">
                            <input type="text" name="language-4" placeholder="Language 4">
                            <input type="text" name="language-5" placeholder="Language 5">
                        </li>
                    </ul>
                </div>
            </div>

            <div class="expand">
                <div class="item">
                    <div class="title">
                        <input type="text" name="interests" value="Interests">
                        <div class="dropdown"></div>
                    </div>
                    <ul>
                        <li>
                            <input type="text" name="interest-1" placeholder="Interest 1">
                            <input type="text" name="interest-2" placeholder="Interest 2">
                            <input type="text" name="interest-3" placeholder="Interest 3">
                            <input type="text" name="interest-4" placeholder="Interest 4">
                            <input type="text" name="interest-5" placeholder="Interest 5">
                            <input type="text" name="interest-6" placeholder="Interest 6">
                            <input type="text" name="interest-7" placeholder="Interest 7">
                            <input type="text" name="interest-8" placeholder="Interest 8">
                            <input type="text" name="interest-9" placeholder="Interest 9">
                            <input type="text" name="interest-10" placeholder="Interest 10">
                        </li>
                    </ul>
                </div>
            </div>

            <div class="expand">
                <div class="item">
                    <div class="title">
                        <input type="text" name="refference" value="Refference">
                        <div class="dropdown"></div>
                    </div>
                    <ul>
                        <li>
                            <input type="text" name="refference-1" placeholder="Reference 1">
                            <textarea name="refference-t-1" placeholder="More info" id=""></textarea>
                        </li>
                        <li>
                            <input type="text" name="refference-2" placeholder="Refference 2">
                            <textarea name="refference-t-2" placeholder="More info" id=""></textarea>
                        </li>
                    </ul>
                </div>
            </div>

            <button class="btn btn-0 show-download-section">Download PDF</button>

            <div class="download-section">
                <div class="container-1">
                    <div class="item">
                        <div class="sub-item">
                            <button class="btn btn-2 submit-btn" type="submit" name="submit">Download</button>
                        </div>
                        <div class="sub-item">
                            <p class="description">Do you know this <b>web application</b> tool <b>costs</b> us to keep it <b>free?</b> Help keep the project alive.</p>
                            <a href="https://gdoop.us/uni-triangle/donate" target="_blank" class="btn btn-0">Donate Us</a>
                            <div>
                                <br>
                                <br>
                                <img class="logo-img" src="./favicon.png" alt="">
                                <p>From</p>
                                <h1>Gdoop Studio.</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </form>

        <div class="item copyrights">
            <p>CV Maker &copy;<?php echo date('Y') ?></p>
            <p>Gdoop Studio.</p>
        </div>

    </div>
</section>