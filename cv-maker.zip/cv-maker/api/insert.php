<?php

require_once __DIR__ . '/vendor/autoload.php';

$mpdf = new \Mpdf\Mpdf([
    'format' => 'A4',
    'margin_top' => 4,
    'margin_bottom' => 4,
    'margin_left' => 4,
    'margin_right' => 4
]);

$mpdf->autoMarginPadding = 0;

// config
require_once('config.php');

$input = file_get_contents('php://input');
$decoded = json_decode($input, true);

if (isset($_POST)) {

    // generate pdf
    $fc01 = $decoded['color-1'];
    $bgc01 = $decoded['color-2'];
    $fc02 = $decoded['color-3'];
    $bgc02 = $decoded['color-4'];

    $data = '';

    $data .= '<style>';
    $data .= "
    body {
    background: $bgc01;
    }
    h1, h2, h3, p, ul, li {
        margin: 0;
        padding: 0;
        font-family: sans-serif;
        color: $fc01;
    }
    h2 {
        background: $bgc02;
        padding: 5px 10px;
        margin-bottom: 10px;
        color: $fc01;
        font-size: 18px;
        border-radius: 5px;
    }
    ul {
        margin-left: 10px;
    }
        .item {
        margin-bottom: 20px;
    }
    .item-a ul li {
        margin-bottom: 10px;
        }
    .copyrights {
        font-size: 12px;
        color: #909090;
        text-align: center;
    }

    ";
    $data .= '</style>';


    $personal = "
        <div class='item'>
            <h1>Ravindu Madhushankha</h1>    
            <p>RP1004/ 13lane/Rajapakshapura/ Seeduwa Gampaha</p>
            <p>077-4301145</p>
            <p>ravindu@gdoop.us</p>
        </div>
    ";

    $objective = "
        <div class='item'>
            <h2>Objective</h2>
            <p>ewter tery e erteetteryet e ytrytr tytrytr etyetry  etytruyet e et ytry etyhtrr rtey tyryury erttrutr ertrytryettwr.</p>
        </div>
    ";

    $experience = "
    <div class='item item-a'>
            <h2>Experience</h2>    
            <ul>
                <li>
                    <h3>Freelance Frontend Web Developer</h3> 
                    <p>Designed and developed over 10 fully functional websites using HTML, CSS, JavaScript, and React.
                    Created responsive and visually appealing web pages that enhanced user experience and
                    accessibility.
                    </p>   
                </li>    
            </ul>
        </div>
    ";

    $education = "
    <div class='item item-a'>
            <h2>Education</h2>    
            <ul>
                <li>
                    <h3>Freelance Frontend Web Developer</h3> 
                    <p>Designed and developed over 10 fully functional websites using HTML, CSS, JavaScript, and React.
                    Created responsive and visually appealing web pages that enhanced user experience and
                    accessibility.
                    </p>   
                </li>    
            </ul>
        </div>
    ";

    $projects = "
    <div class='item item-a'>
            <h2>Projects</h2>    
            <ul>
                <li>
                    <h3>Freelance Frontend Web Developer</h3> 
                    <p>Designed and developed over 10 fully functional websites using HTML, CSS, JavaScript, and React.
                    Created responsive and visually appealing web pages that enhanced user experience and
                    accessibility.
                    </p>   
                </li>    
            </ul>
        </div>
    ";

    $skills = "
    <div class='item'>
            <h2>Skills</h2>    
            <ul>
                <li><p>Web development</p></li>    
                <li><p>Web development</p></li>    
                <li><p>Web development</p></li>    
            </ul>
        </div>
    ";

    $languages = "
    <div class='item'>
            <h2>Languages</h2>    
            <ul>
                <li><p>Sinhala</p></li>    
                <li><p>English</p></li>        
            </ul>
        </div>
    ";

    $refference = "
    <div class='item item-a'>
            <h2>Refference</h2>    
            <ul>
                <li>
                    <h3>Freelance Frontend Web Developer</h3> 
                    <p>Designed and developed over 10 fully functional websites using HTML, CSS, JavaScript, and React.
                    Created responsive and visually appealing web pages that enhanced user experience and
                    accessibility.
                    </p>   
                </li>    
                <li>
                    <h3>Freelance Frontend Web Developer</h3> 
                    <p>Designed and developed over 10 fully functional websites using HTML, CSS, JavaScript, and React.
                    Created responsive and visually appealing web pages that enhanced user experience and
                    accessibility.
                    </p>   
                </li>   
            </ul>
        </div>
    ";

    $copyrights = "
        <div class='copyrights'>
            <p>Gdoop CV Maker | www.gdoop.us</p>
        </div>
    ";

    $data .= "
    <body>
    <div class='container'>

        $personal
        $objective
        $experience
        $education
        $projects
        $skills
        $languages
        $refference
        $copyrights

    </div>
    </body>
    ";

    $mpdf->WriteHTML($data);
    $mpdf->Output('test' . '.pdf', 'D');
    
    echo json_encode(['msg' => 'Done']);
}


?>