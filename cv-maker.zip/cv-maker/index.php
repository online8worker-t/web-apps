<!DOCTYPE html>
<html lang="en">

<head>

    <?php include_once('head.php'); ?>

</head>

<body>

    <section class="home" style="display: none;">
        <div class="container">
            <div class="item">
                <img class="logo" src="./favicon.png" alt="">
                <p>Free Online</p>
                <h1>CV Maker</h1>
                <p>From Gdoop Studio.</p>
                <h2>Your Resume in Minutes.</h2>
                <a href="templates" class="btn-4">Get Started</a>
            </div>
            <div class="item">
                <img src="./assets/cv-templates-2.png" alt="gdoop cv maker">
            </div>
        </div>
    </section>

<script>
    window.onload = function() {
                document.querySelector(".home").style.display = "block";
        };
</script>

</body>

</html>