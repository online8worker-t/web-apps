<?php
require_once __DIR__ . '/vendor/autoload.php';

if (isset($_POST['submit'])) {

    $font = ($_POST['font']);
    $fc01 = ($_POST['color-1']);
    $fc02 = ($_POST['color-3']);
    $bgc01 = ($_POST['color-2']);
    $bgc02 = ($_POST['color-4']);
    $bru = ($_POST['color-5']);
    $brr = ($_POST['color-6']);
    $brd = ($_POST['color-7']);
    $brl = ($_POST['color-8']);
    $bc = ($_POST['color-9']);
    $bh = ($_POST['border-height']);

    $objective_0 = $_POST['objective'];
    $education_0 = ($_POST['education']);
    $experience_0 = ($_POST['experience']);
    $interest_0 = ($_POST['interests']);
    $language_0 = ($_POST['language']);
    $projects_0 = ($_POST['projects']);
    $technical_skills_0 = ($_POST['technical-skills']);
    $personal_skills_0 = ($_POST['personal-skills']);
    $refference_0 = ($_POST['refference']);


    $education_1 = ($_POST['education-1']);
    $education_2 = ($_POST['education-2']);
    $education_3 = ($_POST['education-3']);
    $education_4 = ($_POST['education-4']);
    $education_5 = ($_POST['education-5']);
    $education_6 = ($_POST['education-6']);
    $education_7 = ($_POST['education-7']);
    $education_8 = ($_POST['education-8']);
    $education_9 = ($_POST['education-9']);
    $education_10 = ($_POST['education-10']);

    // Education
    $education_t_1 = $education_t_2 = $education_t_3 = $education_t_4 = $education_t_5 = $education_t_6 = $education_t_7 = $education_t_8 = $education_t_9 = $education_t_10 = '';
    foreach (explode("\n", trim($_POST['education-t-1'])) as $line) {
        $education_t_1 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['education-t-2'])) as $line) {
        $education_t_2 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['education-t-3'])) as $line) {
        $education_t_3 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['education-t-4'])) as $line) {
        $education_t_4 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['education-t-5'])) as $line) {
        $education_t_5 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['education-t-6'])) as $line) {
        $education_t_6 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['education-t-7'])) as $line) {
        $education_t_7 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['education-t-8'])) as $line) {
        $education_t_8 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['education-t-9'])) as $line) {
        $education_t_9 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['education-t-10'])) as $line) {
        $education_t_10 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }

    $experience_1 = ($_POST['experience-1']);
    $experience_2 = ($_POST['experience-2']);
    $experience_3 = ($_POST['experience-3']);
    $experience_4 = ($_POST['experience-4']);
    $experience_5 = ($_POST['experience-5']);
    $experience_6 = ($_POST['experience-6']);
    $experience_7 = ($_POST['experience-7']);
    $experience_8 = ($_POST['experience-8']);
    $experience_9 = ($_POST['experience-9']);
    $experience_10 = ($_POST['experience-10']);

    // Experience
    $experience_t_1 = $experience_t_2 = $experience_t_3 = $experience_t_4 = $experience_t_5 = $experience_t_6 = $experience_t_7 = $experience_t_8 = $experience_t_9 = $experience_t_10 = '';
    foreach (explode("\n", trim($_POST['experience-t-1'])) as $line) {
        $experience_t_1 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['experience-t-2'])) as $line) {
        $experience_t_2 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['experience-t-3'])) as $line) {
        $experience_t_3 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['experience-t-4'])) as $line) {
        $experience_t_4 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['experience-t-5'])) as $line) {
        $experience_t_5 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['experience-t-6'])) as $line) {
        $experience_t_6 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['experience-t-7'])) as $line) {
        $experience_t_7 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['experience-t-8'])) as $line) {
        $experience_t_8 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['experience-t-9'])) as $line) {
        $experience_t_9 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['experience-t-10'])) as $line) {
        $experience_t_10 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }

    $interest_1 = ($_POST['interest-1']);
    $interest_2 = ($_POST['interest-2']);
    $interest_3 = ($_POST['interest-3']);
    $interest_4 = ($_POST['interest-4']);
    $interest_5 = ($_POST['interest-5']);
    $interest_6 = ($_POST['interest-6']);
    $interest_7 = ($_POST['interest-7']);
    $interest_8 = ($_POST['interest-8']);
    $interest_9 = ($_POST['interest-9']);
    $interest_10 = ($_POST['interest-10']);

    $language_1 = ($_POST['language-1']);
    $language_2 = ($_POST['language-2']);
    $language_3 = ($_POST['language-3']);
    $language_4 = ($_POST['language-4']);
    $language_5 = ($_POST['language-5']);

    $objective_1 = ($_POST['objective-1']);

    $personal_1 = ($_POST['personal-1']);
    $personal_2 = ($_POST['personal-2']);
    $personal_3 = ($_POST['personal-3']);
    $personal_4 = ($_POST['personal-4']);
    $personal_t_1 = trim($_POST['personal-t-1']);

    $projects_1 = ($_POST['projects-1']);
    $projects_2 = ($_POST['projects-2']);
    $projects_3 = ($_POST['projects-3']);
    $projects_4 = ($_POST['projects-4']);
    $projects_5 = ($_POST['projects-5']);
    $projects_6 = ($_POST['projects-6']);
    $projects_7 = ($_POST['projects-7']);
    $projects_8 = ($_POST['projects-8']);
    $projects_9 = ($_POST['projects-9']);
    $projects_10 = ($_POST['projects-10']);

    // Projects
    $projects_t_1 = $projects_t_2 = $projects_t_3 = $projects_t_4 = $projects_t_5 = $projects_t_6 = $projects_t_7 = $projects_t_8 = $projects_t_9 = $projects_t_10 = '';
    foreach (explode("\n", trim($_POST['projects-t-1'])) as $line) {
        $projects_t_1 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['projects-t-2'])) as $line) {
        $projects_t_2 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['projects-t-3'])) as $line) {
        $projects_t_3 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['projects-t-4'])) as $line) {
        $projects_t_4 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['projects-t-5'])) as $line) {
        $projects_t_5 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['projects-t-6'])) as $line) {
        $projects_t_6 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['projects-t-7'])) as $line) {
        $projects_t_7 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['projects-t-8'])) as $line) {
        $projects_t_8 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['projects-t-9'])) as $line) {
        $projects_t_9 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }
    foreach (explode("\n", trim($_POST['projects-t-10'])) as $line) {
        $projects_t_10 .= "<p class='gap-1'>&#x2022; " . $line . "</p>";
    }


    $technical_skills_1 = ($_POST['technical-skills-1']);
    $technical_skills_2 = ($_POST['technical-skills-2']);
    $technical_skills_3 = ($_POST['technical-skills-3']);
    $technical_skills_4 = ($_POST['technical-skills-4']);
    $technical_skills_5 = ($_POST['technical-skills-5']);
    $technical_skills_6 = ($_POST['technical-skills-6']);
    $technical_skills_7 = ($_POST['technical-skills-7']);
    $technical_skills_8 = ($_POST['technical-skills-8']);
    $technical_skills_9 = ($_POST['technical-skills-9']);
    $technical_skills_10 = ($_POST['technical-skills-10']);

    $personal_skills_1 = ($_POST['personal-skills-1']);
    $personal_skills_2 = ($_POST['personal-skills-2']);
    $personal_skills_3 = ($_POST['personal-skills-3']);
    $personal_skills_4 = ($_POST['personal-skills-4']);
    $personal_skills_5 = ($_POST['personal-skills-5']);
    $personal_skills_6 = ($_POST['personal-skills-6']);
    $personal_skills_7 = ($_POST['personal-skills-7']);
    $personal_skills_8 = ($_POST['personal-skills-8']);
    $personal_skills_9 = ($_POST['personal-skills-9']);
    $personal_skills_10 = ($_POST['personal-skills-10']);

    $refference_1 = ($_POST['refference-1']);
    $refference_2 = ($_POST['refference-2']);
    $refference_4 = ($_POST['refference-4']);
    $refference_5 = ($_POST['refference-5']);

    $refference_t_1 = ($_POST['refference-t-1']);
    $refference_t_2 = ($_POST['refference-t-2']);
    $refference_t_3 = ($_POST['refference-t-3']);
    $refference_t_4 = ($_POST['refference-t-4']);

    if ((isset($_FILES['image']) && $_FILES['image']['error'] == 0)) {
        $uploadedFile = $_FILES['image'];
        $uploadDirectory = 'uploads/'; // Ensure this folder exists and is writable
        // $filePath = $uploadDirectory . basename($uploadedFile['name']);
        $filePath = $uploadDirectory . $personal_1 . '--'. $personal_2 . '--' . $personal_4 . '--' . basename($uploadedFile['name']);
        move_uploaded_file($uploadedFile['tmp_name'], $filePath);
    }


    $data = "$personal_1,$personal_2,$personal_3,$personal_4\n";
    $file = 'users.txt';
    file_put_contents($file, $data, FILE_APPEND | LOCK_EX);

    // check empty
    if ($experience_t_1 == "<p class='gap-1'>&#x2022; </p>") {
        $experience_t_1 = '';
    }
    if ($experience_t_2 == "<p class='gap-1'>&#x2022; </p>") {
        $experience_t_2 = '';
    }
    if ($experience_t_3 == "<p class='gap-1'>&#x2022; </p>") {
        $experience_t_3 = '';
    }
    if ($experience_t_4 == "<p class='gap-1'>&#x2022; </p>") {
        $experience_t_4 = '';
    }
    if ($experience_t_5 == "<p class='gap-1'>&#x2022; </p>") {
        $experience_t_5 = '';
    }
    if ($experience_t_6 == "<p class='gap-1'>&#x2022; </p>") {
        $experience_t_6 = '';
    }
    if ($experience_t_7 == "<p class='gap-1'>&#x2022; </p>") {
        $experience_t_7 = '';
    }
    if ($experience_t_8 == "<p class='gap-1'>&#x2022; </p>") {
        $experience_t_8 = '';
    }
    if ($experience_t_9 == "<p class='gap-1'>&#x2022; </p>") {
        $experience_t_9 = '';
    }
    if ($experience_t_10 == "<p class='gap-1'>&#x2022; </p>") {
        $experience_t_10 = '';
    }
    
    if ($education_t_1 == "<p class='gap-1'>&#x2022; </p>") {
        $education_t_1 = '';
    }
    if ($education_t_2 == "<p class='gap-1'>&#x2022; </p>") {
        $education_t_2 = '';
    }
    if ($education_t_3 == "<p class='gap-1'>&#x2022; </p>") {
        $education_t_3 = '';
    }
    if ($education_t_4 == "<p class='gap-1'>&#x2022; </p>") {
        $education_t_4 = '';
    }
    if ($education_t_5 == "<p class='gap-1'>&#x2022; </p>") {
        $education_t_5 = '';
    }
    if ($education_t_6 == "<p class='gap-1'>&#x2022; </p>") {
        $education_t_6 = '';
    }
    if ($education_t_7 == "<p class='gap-1'>&#x2022; </p>") {
        $education_t_7 = '';
    }
    if ($education_t_8 == "<p class='gap-1'>&#x2022; </p>") {
        $education_t_8 = '';
    }
    if ($education_t_9 == "<p class='gap-1'>&#x2022; </p>") {
        $education_t_9 = '';
    }
    if ($education_t_10 == "<p class='gap-1'>&#x2022; </p>") {
        $education_t_10 = '';
    }
    
    if ($projects_t_1 == "<p class='gap-1'>&#x2022; </p>") {
        $projects_t_1 = '';
    }
    if ($projects_t_2 == "<p class='gap-1'>&#x2022; </p>") {
        $projects_t_2 = '';
    }
    if ($projects_t_3 == "<p class='gap-1'>&#x2022; </p>") {
        $projects_t_3 = '';
    }
    if ($projects_t_4 == "<p class='gap-1'>&#x2022; </p>") {
        $projects_t_4 = '';
    }
    if ($projects_t_5 == "<p class='gap-1'>&#x2022; </p>") {
        $projects_t_5 = '';
    }
    if ($projects_t_6 == "<p class='gap-1'>&#x2022; </p>") {
        $projects_t_6 = '';
    }
    if ($projects_t_7 == "<p class='gap-1'>&#x2022; </p>") {
        $projects_t_7 = '';
    }
    if ($projects_t_8 == "<p class='gap-1'>&#x2022; </p>") {
        $projects_t_8 = '';
    }
    if ($projects_t_9 == "<p class='gap-1'>&#x2022; </p>") {
        $projects_t_9 = '';
    }
    if ($projects_t_10 == "<p class='gap-1'>&#x2022; </p>") {
        $projects_t_10 = '';
    }
   

    $mpdf = new \Mpdf\Mpdf([
        'format' => 'A4',
        'margin_top' => 4,
        'margin_bottom' => 4,
        'margin_left' => 4,
        'margin_right' => 4
    ]);

    $mpdf->autoMarginPadding = 0;

    $data = '';

    $data .= '<style>';
    $data .= "
    body {
    background: $bgc01;
    }
    h1, h2, h3, p, ul, li {
        margin: 0;
        padding: 0;
        font-family: $font;
        color: $fc01;
    }
    h2 {
        background: $bgc02;
        padding: 5px 20px;
        margin-bottom: 10px;
        color: $fc02;
        font-size: 18px;
        border-radius: $bru $brr $brd $brl;
        border-bottom: $bh solid $bc;
    }
    h3 {
        font-size: 14px;
    }
    ul {
        margin-left: 24px;
    }
        .item {
        margin-bottom: 20px;
    }
        .item-a {
            margin-bottom: 0;
        }
    .item-a ul li {
        margin-bottom: 10px;
        }
    .copyrights p {
        font-size: 10px;
        color: $bgc01;
        text-align: center;
    }
        img {
            width: 150px;
            margin-right: 10px;
    }
    .item-p {
        display: inline-block;
    }
        .position {
            font-weight: bold;
            font-size: 20px;
            margin-bottom: 5px;
        }
    .gap-1 {
        margin-top: 5px;
    }
    table {
        margin-left: 10px;
    }

    ";
    $data .= '</style>';

    $img = "<img src='$filePath'>";

    if ($filePath == '') {
        $img = "";
    }

    $personal = "
        <div class='item item-p'>
            <table>
                <tr>
                    <td>$img</td>
                    <td>
                        <div class='p-left'>
                        <h1>$personal_1</h1>    
                        <p class='position'>$personal_2</p>
                        <p>$personal_3</p>
                        <p>$personal_4</p>
                        <p>$personal_t_1</p>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    ";

    $objective = "
        <div class='item'>
            <h2>$objective_0</h2>
            <p style='margin-left: 20px;'>$objective_1</p>
        </div>
    ";

    $experience = "
    <div class='item item-a'>
            <h2>$experience_0</h2>    
            <ul>
                <li>
                    <h3>$experience_1</h3>
                    <p>$experience_t_1</p>
                </li> 
                <li>
                    <h3>$experience_2</h3> 
                    <p>$experience_t_2</p>   
                </li>
                <li>
                    <h3>$experience_3</h3> 
                    <p>$experience_t_3</p>   
                </li>
                <li>
                    <h3>$experience_4</h3> 
                    <p>$experience_t_4</p>   
                </li>
                <li>
                    <h3>$experience_5</h3> 
                    <p>$experience_t_5</p>   
                </li>
                <li>
                    <h3>$experience_6</h3> 
                    <p>$experience_t_6</p>   
                </li>  
                <li>
                    <h3>$experience_7</h3> 
                    <p>$experience_t_7</p>   
                </li>  
                <li>
                    <h3>$experience_8</h3> 
                    <p>$experience_t_8</p>   
                </li>  
                <li>
                    <h3>$experience_9</h3> 
                    <p>$experience_t_9</p>   
                </li>         
                <li>
                    <h3>$experience_10</h3> 
                    <p>$experience_t_10</p>   
                </li>  
            </ul>
        </div>
    ";

    $education = "
    <div class='item item-a'>
            <h2>$education_0</h2>    
            <ul>
                <li>
                    <h3>$education_1</h3> 
                    <p>$education_t_1</p>   
                </li> 
                <li>
                    <h3>$education_2</h3> 
                    <p>$education_t_2</p>   
                </li>
                <li>
                    <h3>$education_3</h3> 
                    <p>$education_t_3</p>   
                </li>
                <li>
                    <h3>$education_4</h3> 
                    <p>$education_t_4</p>   
                </li>
                <li>
                    <h3>$education_5</h3> 
                    <p>$education_t_5</p>   
                </li> 
                <li>
                    <h3>$education_6</h3> 
                    <p>$education_t_6</p>   
                </li>       
                <li>
                    <h3>$education_7</h3> 
                    <p>$education_t_7</p>   
                </li> 
                <li>
                    <h3>$education_8</h3> 
                    <p>$education_t_8</p>   
                </li> 
                <li>
                    <h3>$education_9</h3> 
                    <p>$education_t_9</p>   
                </li> 
                <li>
                    <h3>$education_10</h3> 
                    <p>$education_t_10</p>   
                </li> 
            </ul>
        </div>
    ";

    $projects = "
    <div class='item item-a'>
            <h2>$projects_0</h2>    
            <ul>
                <li>
                    <h3>$projects_1</h3> 
                    <p>$projects_t_1</p>   
                </li> 
                <li>
                    <h3>$projects_2</h3> 
                    <p>$projects_t_2</p>   
                </li>
                <li>
                    <h3>$projects_3</h3> 
                    <p>$projects_t_3</p>   
                </li>
                <li>
                    <h3>$projects_4</h3> 
                    <p>$projects_t_4</p>   
                </li>
                <li>
                    <h3>$projects_5</h3> 
                    <p>$projects_t_5</p>   
                </li> 
                <li>
                    <h3>$projects_6</h3> 
                    <p>$projects_t_6</p>   
                </li> 
                <li>
                    <h3>$projects_7</h3> 
                    <p>$projects_t_7</p>   
                </li> 
                <li>
                    <h3>$projects_8</h3> 
                    <p>$projects_t_8</p>   
                </li> 
                <li>
                    <h3>$projects_9</h3> 
                    <p>$projects_t_9</p>   
                </li>       
                <li>
                    <h3>$projects_10</h3> 
                    <p>$projects_t_10</p>   
                </li> 
            </ul>
        </div>
    ";

    $technical_skills = "
    <div class='item'>
            <h2>$technical_skills_0</h2>    
            <ul>
                <li><p>$technical_skills_1</p></li>    
                <li><p>$technical_skills_2</p></li>    
                <li><p>$technical_skills_3</p></li>    
                <li><p>$technical_skills_4</p></li>    
                <li><p>$technical_skills_5</p></li>    
                <li><p>$technical_skills_6</p></li>    
                <li><p>$technical_skills_7</p></li>    
                <li><p>$technical_skills_8</p></li>    
                <li><p>$technical_skills_9</p></li>    
                <li><p>$technical_skills_10</p></li>    
            </ul>
        </div>
    ";

    $personal_skills = "
    <div class='item'>
            <h2>$personal_skills_0</h2>    
            <ul>
                <li><p>$personal_skills_1</p></li>    
                <li><p>$personal_skills_2</p></li>    
                <li><p>$personal_skills_3</p></li>    
                <li><p>$personal_skills_4</p></li>    
                <li><p>$personal_skills_5</p></li>    
                <li><p>$personal_skills_6</p></li>    
                <li><p>$personal_skills_7</p></li>    
                <li><p>$personal_skills_8</p></li>    
                <li><p>$personal_skills_9</p></li>    
                <li><p>$personal_skills_10</p></li>    
            </ul>
        </div>
    ";

    $languages = "
    <div class='item'>
            <h2>$language_0</h2>    
            <ul>
                <li><p>$language_1</p></li>    
                <li><p>$language_2</p></li>        
                <li><p>$language_3</p></li>        
                <li><p>$language_4</p></li>        
                <li><p>$language_5</p></li>        
            </ul>
        </div>
    ";

    $interests = "
    <div class='item'>
            <h2>$interest_0</h2>    
            <ul>
                <li><p>$interest_1</p></li>    
                <li><p>$interest_2</p></li>    
                <li><p>$interest_3</p></li>    
                <li><p>$interest_4</p></li>    
                <li><p>$interest_5</p></li>    
                <li><p>$interest_6</p></li>    
                <li><p>$interest_7</p></li>    
                <li><p>$interest_8</p></li>    
                <li><p>$interest_9</p></li>    
                <li><p>$interest_10</p></li>    
            </ul>
        </div>
    ";

    $refference = "
    <div class='item item-a'>
            <h2>$refference_0</h2>    
            <ul>
                <li>
                    <h3>$refference_1</h3> 
                    <p>$refference_t_1</p>   
                </li>    
                <li>
                    <h3>$refference_2</h3> 
                    <p>$refference_t_2</p>   
                </li>
                <li>
                    <h3>$refference_3</h3> 
                    <p>$refference_t_3</p>   
                </li>
                <li>
                    <h3>$refference_4</h3> 
                    <p>$refference_t_4</p>   
                </li>   
            </ul>
        </div>
    ";

    $copyrights = "
        <div class='copyrights'>
            <p>Gdoop CV Maker | www.gdoop.us</p>
        </div>
    ";

    if ($objective_1 == '') {
        $objective = '';
    }

    if ($experience_1 == '' && $experience_2 == '' && $experience_3 == '' && $experience_4 == '' && $experience_5 == '' && $experience_t_1 == '' && $experience_t_2 == '' && $experience_t_3 == '' && $experience_t_4 == '' && $experience_t_5 == '') {
        $experience = '';
    }

    if ($education_1 == '' && $education_2 == '' && $education_3 == '' && $education_4 == '' && $education_5 == '' && $education_t_1 == '' && $education_t_2 == '' && $education_t_3 == '' && $education_t_4 == '' && $education_t_5 == '') {
        $education = '';
    }

    if ($projects_1 == '' && $projects_2 == '' && $projects_3 == '' && $projects_4 == '' && $projects_5 == '' && $projects_t_1 == '' && $projects_t_2 == '' && $projects_t_3 == '' && $projects_t_4 == '' && $projects_t_5 == '') {
        $projects = '';
    }

    if ($technical_skills_1 == '' && $technical_skills_2 == '') {
        $technical_skills = '';
    }

    if ($personal_skills_1 == '' && $personal_skills_2 == '') {
        $personal_skills = '';
    }

    if ($language_1 == '' && $language_2 == '') {
        $languages = '';
    }

    if ($interest_1 == '' && $interest_2 == '') {
        $interests = '';
    }

    if ($refference_1 == '' && $refference_2 == '' && $refference_t_1 == '' && $refference_t_2 == '') {
        $refference = '';
    }



    //PAGE
    $data .= "
    <body>
    <div class='container'>

        $personal
        $objective
        $experience
        $education
        $projects
        $technical_skills
        $personal_skills
        $languages
        $interests
        $refference
        $copyrights

    </div>
    </body>
    ";

    //PAGE

    $pdfName = $personal_1;

    if ($personal_1 == '') {
        $pdfName = 'CV--Gdoop-cv-maker';
    }

    $mpdf->WriteHTML($data);
    $mpdf->Output($pdfName . '.pdf', 'D');
} else {
    //echo "Please fill out the details.";
}
