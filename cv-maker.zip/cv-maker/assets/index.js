document.querySelectorAll('.title').forEach(item => {
    item.addEventListener('click', () => {
        const parent = item.parentNode;
        const parent2 = parent.parentNode;
        parent2.classList.toggle('active');
    });
});
document.querySelector('.expand:nth-child(2)').classList.add('active')

// sidebar
const menuBtn = document.querySelector('.menu-icon')
const sidebar = document.querySelector('.sidebar')

menuBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active')
})

// get image name
document.querySelector('.remove-img-btn').style.display = 'none';

document.getElementById('file').addEventListener('change', e => {
    const file = e.target.files[0]; // Get the selected file
    const label = document.querySelector('label'); // Select the label
    const maxSize = 300 * 1024; // 300KB in bytes
    
    if (file) {
        document.querySelector('.remove-img-btn').style.display = 'block';
        if (file.size > maxSize) {
            label.textContent = "File is too large! (Max: 300KB)"; // Show error message
            label.style.color = "red"; // Change text color
        } else {
            label.textContent = file.name; // Display file name
            label.style.color = "green"; // Reset text color
        }
    }
});
document.querySelector('.remove-img-btn').addEventListener('click', () => {
    document.getElementById('file').value = '';
    document.querySelector('label').textContent = 'Upload profile picture (width: 164px, height: 164px, max size: 300kb)';
    console.log('r')
    document.querySelector('label').style.color = '#000000';
    document.querySelector('.remove-img-btn').style.display = 'none';
})


// submit button
document.querySelector('.show-download-section').addEventListener('click', (e) => {
    e.preventDefault()
    document.querySelector('.download-section').classList.add('active')
})

// Remove the 'active' class when clicking outside '.download-section'
document.addEventListener('click', (event) => {
    const downloadSection = document.querySelector('.download-section');
    if (!event.target.classList.contains('show-download-section')) {
        downloadSection.classList.remove('active'); // Remove class
    }
});

document.querySelector('.submit-btn').addEventListener('click', () => {
    document.querySelector(".download-section").classList.remove("active");
})



// splash screen
setTimeout(() => {
    document.querySelector(".login").classList.remove("active");
}, 3000); 

// avoid leaving the page
window.addEventListener("beforeunload", function (event) {
    event.preventDefault();
    event.returnValue = "Are you sure you want to leave this page?";
});