<?php

if (isset($_GET['color-1']) && isset($_GET['color-2'])) {
    $font = ($_GET['font']);
    $fc01 = ($_GET['color-1']);
    $bgc01 = ($_GET['color-2']);
    $fc02 = ($_GET['color-3']);
    $bgc02 = ($_GET['color-4']);
    $bru = ($_GET['b1']);
    $brr = ($_GET['b2']);
    $brd = ($_GET['b3']);
    $brl = ($_GET['b4']);
    $bc = ($_GET['color-9']);
    $bh = ($_GET['bh']);
} else {
    header('Location: templates');
}


?>

<!DOCTYPE html>
<html lang="en">

<head>

    <?php include_once('head.php'); ?>

</head>

<body>

    <?php require_once 'header.php' ?>
    <?php require_once 'login.php' ?>


    <!-- app -->
    <section id="section-0">
        <div class="container">

            <form class="form-1" action="generate" method="post" enctype="multipart/form-data" target="hidden_iframe">

                <div class="expand">
                    <div class="item theme">
                        <div class="title">
                            <input type="text" value="Appearance" disabled>
                            <div class="dropdown"></div>
                        </div>
                        <ul>
                            <li>
                                <p>Font</p>
                                <select name="font" id="">
                                    <option value="<?php echo $font; ?>">Default</option>
                                    <option value="serif">Times New Romans</option>
                                    <option value="sans-serif">Helvetica</option>
                                    <option value="courier">Courier</option>
                                </select>
                                <p>Font colour</p>
                                <input type="color" name="color-1" value="#<?php echo $fc01; ?>">
                                <p>Page background colour</p>
                                <input type="color" name="color-2" value="#<?php echo $bgc01; ?>">
                                <p>Title font colour</p>
                                <input type="color" name="color-3" value="#<?php echo $fc02; ?>">
                                <p>Title background colour</p>
                                <input type="color" name="color-4" value="#<?php echo $bgc02; ?>">
                                <p>Border bottom colour of title</p>
                                <input type="color" name="color-9" value="#<?php echo $bc; ?>">
                                <p>Border height</p>
                                <input type="number" name="border-height" value="<?php echo $bh; ?>">
                                <br>
                                <p>Border radius of title</p>
                                <p>Border top left</p>
                                <input type="number" name="color-5" value="<?php echo $bru; ?>">
                                <p>Border top right</p>
                                <input type="number" name="color-6" value="<?php echo $brr; ?>">
                                <p>Border bottom right</p>
                                <input type="number" name="color-7" value="<?php echo $brd; ?>">
                                <p>Border bottom left</p>
                                <input type="number" name="color-8" value="<?php echo $brl; ?>">
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="expand">
                    <div class="item">
                        <div class="title personal">
                            <input type="text" name="personal" value="Personal" disabled>
                            <div class="dropdown"></div>
                        </div>
                        <ul>
                            <li>
                                <input type="text" name="personal-1" placeholder="Name">
                                <input type="text" name="personal-2" placeholder="School Leaver/Engineer/Doctor/Designer/Developer">
                                <input type="text" name="personal-3" placeholder="Location/Address">
                                <input type="text" name="personal-4" placeholder="Mobile number">
                                <textarea name="personal-t-1" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <label for="file">Upload profile picture (format: jpeg, width: 164px, height: 164px, max size: 300kb)</label>
                                <div class="btn-5 remove-img-btn">Remove profile picture</div>
                                <input id="file" type="file" name="image" style="display: none;">
                                <br>
                                <a class="btn-2" target="_blank" href="https://gdoop.us/image-resizer/">Reduce image size</a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="expand">
                    <div class="item">
                        <div class="title">
                            <input type="text" name="objective" value="Profile Summary">
                            <div class="dropdown"></div>
                        </div>
                        <ul>
                            <li>
                                <textarea name="objective-1" id="" placeholder="Highly motivated and detail-oriented [Your Profession] with a strong background in ..."></textarea>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="expand">
                    <div class="item">
                        <div class="title">
                            <input type="text" name="experience" value="Experience">
                            <div class="dropdown"></div>
                        </div>
                        <ul>
                            <li>
                                <input type="text" name="experience-1" placeholder="Experience 1">
                                <textarea name="experience-t-1" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="experience-2" placeholder="Experience 2">
                                <textarea name="experience-t-2" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="experience-3" placeholder="Experience 3">
                                <textarea name="experience-t-3" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="experience-4" placeholder="Experience 4">
                                <textarea name="experience-t-4" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="experience-5" placeholder="Experience 5">
                                <textarea name="experience-t-5" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="experience-6" placeholder="Experience 6">
                                <textarea name="experience-t-6" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="experience-7" placeholder="Experience 7">
                                <textarea name="experience-t-7" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="experience-8" placeholder="Experience 8">
                                <textarea name="experience-t-8" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="experience-9" placeholder="Experience 9">
                                <textarea name="experience-t-9" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="experience-10" placeholder="Experience 10">
                                <textarea name="experience-t-10" placeholder="More info" id=""></textarea>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="expand">
                    <div class="item">
                        <div class="title">
                            <input type="text" name="education" value="Education">
                            <div class="dropdown"></div>
                        </div>
                        <ul>
                            <li>
                                <input type="text" name="education-1" placeholder="Education 1">
                                <textarea name="education-t-1" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="education-2" placeholder="Education 2">
                                <textarea name="education-t-2" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="education-3" placeholder="Education 3">
                                <textarea name="education-t-3" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="education-4" placeholder="Education 4">
                                <textarea name="education-t-4" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="education-5" placeholder="Education 5">
                                <textarea name="education-t-5" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="education-6" placeholder="Education 6">
                                <textarea name="education-t-6" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="education-7" placeholder="Education 7">
                                <textarea name="education-t-7" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="education-8" placeholder="Education 8">
                                <textarea name="education-t-8" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="education-9" placeholder="Education 9">
                                <textarea name="education-t-9" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="education-10" placeholder="Education 10">
                                <textarea name="education-t-10" placeholder="More info" id=""></textarea>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="expand">
                    <div class="item">
                        <div class="title">
                            <input type="text" name="projects" value="Projects">
                            <div class="dropdown"></div>
                        </div>
                        <ul>
                            <li>
                                <input type="text" name="projects-1" placeholder="Project 1">
                                <textarea name="projects-t-1" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="projects-2" placeholder="Project 2">
                                <textarea name="projects-t-2" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="projects-3" placeholder="Project 3">
                                <textarea name="projects-t-3" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="projects-4" placeholder="Project 4">
                                <textarea name="projects-t-4" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="projects-5" placeholder="Project 5">
                                <textarea name="projects-t-5" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="projects-6" placeholder="Project 6">
                                <textarea name="projects-t-6" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="projects-7" placeholder="Project 7">
                                <textarea name="projects-t-7" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="projects-8" placeholder="Project 8">
                                <textarea name="projects-t-8" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="projects-9" placeholder="Project 9">
                                <textarea name="projects-t-9" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="projects-10" placeholder="Project 10">
                                <textarea name="projects-t-10" placeholder="More info" id=""></textarea>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="expand">
                    <div class="item">
                        <div class="title">
                            <input type="text" name="technical-skills" value="Technical Skills">
                            <div class="dropdown"></div>
                        </div>
                        <ul>
                            <li>
                                <input type="text" name="technical-skills-1" placeholder="Technical Skill 1">
                                <input type="text" name="technical-skills-2" placeholder="Technical Skill 2">
                                <input type="text" name="technical-skills-3" placeholder="Technical Skill 3">
                                <input type="text" name="technical-skills-4" placeholder="Technical Skill 4">
                                <input type="text" name="technical-skills-5" placeholder="Technical Skill 5">
                                <input type="text" name="technical-skills-6" placeholder="Technical Skill 6">
                                <input type="text" name="technical-skills-7" placeholder="Technical Skill 7">
                                <input type="text" name="technical-skills-8" placeholder="Technical Skill 8">
                                <input type="text" name="technical-skills-9" placeholder="Technical Skill 9">
                                <input type="text" name="technical-skills-10" placeholder="Technical Skill 10">
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="expand">
                    <div class="item">
                        <div class="title">
                            <input type="text" name="personal-skills" value="Personal Skills">
                            <div class="dropdown"></div>
                        </div>
                        <ul>
                            <li>
                                <input type="text" name="personal-slkils-1" placeholder="Personal Skill 1">
                                <input type="text" name="personal-skills-2" placeholder="Personal Skill 2">
                                <input type="text" name="personal-skills-3" placeholder="Personal Skill 3">
                                <input type="text" name="personal-skills-4" placeholder="Personal Skill 4">
                                <input type="text" name="personal-skills-5" placeholder="Personal Skill 5">
                                <input type="text" name="personal-skills-6" placeholder="Personal Skill 6">
                                <input type="text" name="personal-skills-7" placeholder="Personal Skill 7">
                                <input type="text" name="personal-skills-8" placeholder="Personal Skill 8">
                                <input type="text" name="personal-skills-9" placeholder="Personal Skill 9">
                                <input type="text" name="personal-skills-10" placeholder="Personal Skill 10">
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="expand">
                    <div class="item">
                        <div class="title">
                            <input type="text" name="language" value="Languages">
                            <div class="dropdown"></div>
                        </div>
                        <ul>
                            <li>
                                <input type="text" name="language-1" placeholder="Language 1">
                                <input type="text" name="language-2" placeholder="Language 2">
                                <input type="text" name="language-3" placeholder="Language 2">
                                <input type="text" name="language-4" placeholder="Language 4">
                                <input type="text" name="language-5" placeholder="Language 5">
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="expand">
                    <div class="item">
                        <div class="title">
                            <input type="text" name="interests" value="Interests">
                            <div class="dropdown"></div>
                        </div>
                        <ul>
                            <li>
                                <input type="text" name="interest-1" placeholder="Interest 1">
                                <input type="text" name="interest-2" placeholder="Interest 2">
                                <input type="text" name="interest-3" placeholder="Interest 3">
                                <input type="text" name="interest-4" placeholder="Interest 4">
                                <input type="text" name="interest-5" placeholder="Interest 5">
                                <input type="text" name="interest-6" placeholder="Interest 6">
                                <input type="text" name="interest-7" placeholder="Interest 7">
                                <input type="text" name="interest-8" placeholder="Interest 8">
                                <input type="text" name="interest-9" placeholder="Interest 9">
                                <input type="text" name="interest-10" placeholder="Interest 10">
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="expand">
                    <div class="item">
                        <div class="title">
                            <input type="text" name="refference" value="Reference">
                            <div class="dropdown"></div>
                        </div>
                        <ul>
                            <li>
                                <input type="text" name="refference-1" placeholder="Reference 1">
                                <textarea name="refference-t-1" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="refference-2" placeholder="Refference 2">
                                <textarea name="refference-t-2" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="refference-3" placeholder="Refference 3">
                                <textarea name="refference-t-3" placeholder="More info" id=""></textarea>
                            </li>
                            <li>
                                <input type="text" name="refference-4" placeholder="Refference 4">
                                <textarea name="refference-t-4" placeholder="More info" id=""></textarea>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="buttons">
                <button class="btn btn-0 show-download-section">Download PDF</button>
                <!-- <button class="btn btn-0">Download JSON</button> -->
                </div>

                <div class="download-section">
                    <div class="container-1">
                        <div class="item">
                            <div class="sub-item">
                                <button class="btn btn-2 submit-btn" type="submit" name="submit">Download</button>
                            </div>
                            <div class="sub-item">
                                <p class="description">Do you know this <b>web application</b> tool <b>costs</b> us to keep it <b>free?</b> Help keep the project alive.</p>
                                <a href="https://gdoop.us/uni-triangle/donate" target="_blank" class="btn btn-0">Donate Us</a>
                                <div>
                                    <br>
                                    <br>
                                    <img class="logo-img" src="./favicon.png" alt="">
                                    <p>From</p>
                                    <h1>Gdoop Studio.</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </form>

            <iframe name="hidden_iframe" style="display:none;"></iframe>

            <div class="item copyrights">
                <p>CV Maker</p>
                <p>&copy; <?php echo date('Y') ?> Gdoop. All Right Reserved.</p>
            </div>

        </div>
    </section>

</body>

</html>