<!-- Basic Page Setup -->
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gdoop CV Maker | Create Professional Resumes Instantly</title>
<meta name="description" content="Create a professional CV or resume online for free with our easy-to-use CV Maker. Choose from multiple templates, customize your details, and download instantly.">
<meta name="keywords" content="Gdoop CV Maker, Resume Builder, Online CV, Free Resume Creator, Professional CV, Job Application, Resume Templates">
<meta name="author" content="Your Website Name">

<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">

<!-- Open Graph (OG) for Social Media Sharing -->
<meta property="og:title" content="Free Online CV Maker - Build Your Resume in Minutes">
<meta property="og:description" content="Easily create a professional CV online with our CV Maker. Select colours, customize your information, and download your resume for free.">
<meta property="og:image" content="https://gdoop.us/cv-maker/assets/preview.jpg"> <!-- Add your preview image URL -->
<meta property="og:url" content="https://www.gdoop.us/cv-maker">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Gdoop CV Maker">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Free Online CV Maker - Build Your Resume in Minutes">
<meta name="twitter:description" content="Create a professional CV online using our free CV Maker. Choose a template, customize, and download your resume instantly.">
<meta name="twitter:image" content="https://www.yourwebsite.com/images/preview.jpg"> <!-- Replace with your image URL -->
<meta name="twitter:site" content="@yourtwitterhandle"> <!-- Your Twitter username -->

<!-- Canonical Tag (Avoid Duplicate Content Issues) -->
<link rel="canonical" href="https://www.gdoop.us/cv-maker">

<!-- Favicons -->
<link rel="icon" href="favicon.png">
<link rel="apple-touch-icon" href="favicon.png">

<!-- Schema Markup (Structured Data for Search Engines) -->
<script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": "Gdoop CV Maker",
        "url": "https://www.gdoop.us/cv-maker",
        "description": "Create a professional CV or resume online with our easy-to-use CV Maker. Choose from multiple templates, customize your details, and download instantly.",
        "image": "https://gdoop.us/cv-maker/assets/preview.jpg",
        "sameAs": [
            "https://www.facebook.com/yourpage",
            "https://twitter.com/yourtwitterhandle",
            "https://www.linkedin.com/company/yourcompany"
        ]
    }
</script>

<!-- Robots Meta (Indexing Instructions for Search Engines) -->
<meta name="robots" content="index, follow">

<!-- fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="./assets/fonts.css">
<link rel="stylesheet" href="./assets/index.css?v=1.5">
<script src="./assets/index.js?v=1.5" defer></script>