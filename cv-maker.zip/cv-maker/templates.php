<!DOCTYPE html>
<html lang="en">

<head>

    <?php include_once('head.php'); ?>

</head>

<body>

<header>
    <div class="container">
        <div class="item">
            <a href="index" class="logo">
                <img class="logo-img" src="./favicon.png" alt="gdoop cv maker main logo">
            </a>
            <div class="logo words">CV Maker</div>
        </div>
        <a class="btn-1" href="./assets/gdoop-cv-maker.mp4" target="_blank" class="item">How to use</a>
    </div>
</header>

    <section class="templates" style="display: none;">

        <h2>Select template</h2>

        <div class="container">

        <a href="app?font=serif&color-1=000000&color-2=ffffff&color-3=000000&color-4=ffffff&color-9=ff0066&b1=0&b2=0&b3=0&b4=0&bh=1&v=1.1" target="_blank" class="template">
                <img src="./template/t (0).webp" alt="">
            </a>

            <a href="app?font=serif&color-1=000000&color-2=ffffff&color-3=ffffff&color-4=e70045&color-9=e70045&b1=5&b2=5&b3=5&b4=5&bh=1&v=1.1" target="_blank" class="template">
                <img src="./template/t (1).webp" alt="">
            </a>

            <a href="app?font=sans-serif&color-1=eeeeee&color-2=8f4500&color-3=ffffff&color-4=8f4500&color-9=8f4500&b1=0&b2=0&b3=0&b4=0&bh=1&v=1.1" target="_blank" class="template">
                <img src="./template/t (2).webp" alt="">
            </a>

            <a href="app?font=sans-serif&color-1=eeeeee&color-2=186ea0&color-3=ffffff&color-4=186ea0&color-9=186ea0&b1=0&b2=0&b3=0&b4=0&bh=1&v=1.1" target="_blank" class="template">
                <img src="./template/t (3).webp" alt="">
            </a>

            <a href="app?font=serif&color-1=000000&color-2=ffffff&color-3=000000&color-4=b3d300&color-9=b3d300&b1=5&b2=5&b3=5&b4=5&bh=1&v=1.1" target="_blank" class="template">
                <img src="./template/t (4).webp" alt="">
            </a>

            <a href="app?font=serif&color-1=000000&color-2=ffffff&color-3=54008b&color-4=dddddd&color-9=dddddd&b1=5&b2=5&b3=5&b4=5&bh=1&v=1.1" target="_blank" class="template">
                <img src="./template/t (5).webp" alt="">
            </a>

            <a href="app?font=sans-serif&color-1=eeeeee&color-2=141414&color-3=ffffff&color-4=005e37&color-9=005e37&b1=5&b2=5&b3=5&b4=5&bh=1&v=1.1" target="_blank" class="template">
                <img src="./template/t (6).webp" alt="">
            </a>
            
        </div>
    </section>

<script>
    window.onload = function() {
                document.querySelector(".templates").style.display = "block";
        };
</script>

</body>

</html>