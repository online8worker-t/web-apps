<header>
    <div class="container">
        <div class="item">
            <svg class="menu-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z" />
            </svg>
            <a href="index" class="logo">
                <img class="logo-img" src="./favicon.png" alt="gdoop cv maker main logo">
            </a>
            <div class="logo words">CV Maker</div>
        </div>
        <a class="btn-1" href="./assets/gdoop-cv-maker.mp4" target="_blank" class="item">How to use</a>
    </div>
</header>

<?php include_once('sidebar.php') ?>