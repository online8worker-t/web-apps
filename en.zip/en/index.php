<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Gdoop - See your text anytime, anywhere.</title>
    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-4W59EES7L6"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-4W59EES7L6');
</script>
</head>

<body>
    <?php include_once('header.php') ?>
    <?php include_once('apps.php') ?>

    <section>
        <div class="container">
            <h1>See your text anytime, anywhere.</h1>
        </div>

        <div class="form-1 go-code">
            <input id="code" type="text" placeholder="Gdoop Share Code">
            <div class="buttons">
                <div class="go-btn">See Text</div>
                <a target="_blank" style="text-decoration: none;" href="https://gdoop.us/share" class="">Generate New Text</a>
            </div>
        </div>

    </section>

    <footer>
        <div class="container">
            <a href="https://gdoop.us/freelancing/#about-us">About</a>
            <a href="https://gdoop.us/freelancing/#contact">Contact</a>
            <a href="https://gdoop.us/freelancing/#services">Services</a>
            <a href="https://gdoop.us/careers">Careers</a>
            <a href="https://gdoop.us/studio/licenses">Licenses</a>
            <a href="https://gdoop.us/@ravindu/feedback">Feedback</a>
            <a href="https://gdoop.us/@ravindu">Developers</a>
            <a href="https://gdoop.us/">Support</a>
            <a href="https://gdoop.us/">Advertising</a>
            <a href="https://gdoop.us/studio">Gdoop Studio</a>
            <a href="https://youtube.com/@GdoopStudio">Music</a>
            <a href="https://gdoop.us/studio/apps">Apps</a>
            <a href="https://gdoop.us/@ravindu">Ravindu</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms and Conditions</a>
        </div>
        <p>&copy; 2022 - <?php echo date('Y') ?> Gdoop.</p>
    </footer>

</body>

</html>