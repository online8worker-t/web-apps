window.addEventListener("load", function () {
    // Check if the page has already been reloaded
    if (!sessionStorage.getItem("cacheCleared")) {
        
        // Clear Local Storage
        localStorage.clear();

        // Clear Session Storage (Except the reload flag)
        sessionStorage.clear();
        sessionStorage.setItem("cacheCleared", "true");

        // Clear Cookies
        document.cookie.split(";").forEach(function (c) {
            document.cookie = c
                .replace(/^ +/, "")
                .replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
        });

        // Reload Page
        location.reload(true);
    }
});


const appsBtn = document.querySelector('.apps-btn');
const closeBtn = document.querySelector('.close-btn');
const apps = document.querySelector('.apps');

appsBtn.addEventListener('click', () => {
    apps.classList.add('active');
})

closeBtn.addEventListener('click', () => {
    apps.classList.remove('active');
})


// Preloader
window.addEventListener('load', () => {
    document.querySelector('.loader').classList.add('hide')
    
})



document.addEventListener('DOMContentLoaded', function() {
    // Collect visitor data
    const visitorData = {
        screenWidth: screen.width,
        screenHeight: screen.height,
        browser: detectBrowser()
    };

    // Send data to PHP backend
    fetch('api-0.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(visitorData)
    })
    .then(response => response.json())
    .then(data => {
        // console.log('Visitor data saved:', data);
    })
    .catch(error => {
        console.error('Error:', error);
    });

    // Simple browser detection
    function detectBrowser() {
        const userAgent = navigator.userAgent;
        if (userAgent.includes('Firefox')) return 'Firefox';
        if (userAgent.includes('Safari') && !userAgent.includes('chrome')) return 'Safari';
        if (userAgent.includes('Chrome')) return 'Chrome';
        if (userAgent.includes('Edge')) return 'Edge';
        if (userAgent.includes('Opera') || userAgent.includes('OPR')) return 'Opera';
        if (userAgent.includes('Trident')) return 'Internet Explorer';
        return 'Unknown';
    }
});


// go-code
document.querySelector('.go-btn').addEventListener('click', () => {
    const code = document.getElementById('code').value;
    window.location.href = `https://gdoop.us/share/v?i=${code}`;
})