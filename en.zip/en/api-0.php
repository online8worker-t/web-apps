<?php
// Set the file path
$file = 'logs--2025-' . date('m') . '.csv';

// Get visitor data
$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d H:i:s');
$userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';
$referrer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'Direct visit';

// Additional data from JavaScript
$jsData = json_decode(file_get_contents('php://input'), true);
$screenWidth = $jsData['screenWidth'] ?? 'Unknown';
$screenHeight = $jsData['screenHeight'] ?? 'Unknown';
$browser = $jsData['browser'] ?? 'Unknown';

// Prepare data to save
$data = [
    'IP' => $ip,
    'Date' => $date,
    'Browser' => $browser,
    'ScreenResolution' => $screenWidth . 'x' . $screenHeight,
    'UserAgent' => $userAgent,
    'Referrer' => $referrer,
];

// Format the data line
$line = '"' . implode('","', array_map('str_replace', array_fill(0, count($data), '"'), array_fill(0, count($data), '""'), $data)) . '"' . PHP_EOL;

// Save to file (append mode)
file_put_contents($file, $line, FILE_APPEND | LOCK_EX);

// Send response
header('Content-Type: application/json');
echo json_encode(['status' => 'success', 'message' => 'Page loaded.']);
?>