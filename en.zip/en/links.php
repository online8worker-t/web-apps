<?php

header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>

<?php

$version = '?' . uniqid('');
$appName = "Gdoop";
$description = "See your text anytime, anywhere.";

// #dd1e6e

?>


<meta name="theme-color" content="<?php echo $primaryColor; ?>">

<meta name="description" content="Global free copy paste platform">
<meta name="keywords" content="Share, HNDE, hnde, cover page, ravindu, madhushankha, gdoop, assignments, practicals, experiments, music, series, movies, tutorials, hnde triangle, share, cv maker">
<link rel="canonical" href="https://gdoop.us/en/">

<link rel="shortcut icon" href="https://gdoop.us/en/favicon.png<?php echo $version; ?>">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="index.css<?php echo $version; ?>">
<script src="index.js<?php echo $version; ?>" defer></script>
<script src="projects/apps.js<?php echo $version; ?>" defer></script>
<script src="protection.js<?php echo $version; ?>" defer></script>

<!-- Open Graph (OG) for Social Media Sharing -->
<meta property="og:title" content="See your text anytime, anywhere.">
<meta property="og:description" content="Created by Ravindu Madhushankha">
<meta property="og:image" content="https://gdoop.us/en/view.png">
<!-- Add your preview image URL -->
<meta property="og:url" content="https://www.gdoop.us/en/">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Gdoop">

<!-- Schema Markup (Structured Data for Search Engines) -->
<script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": "Gdoop",
        "url": "https://www.gdoop.us/",
        "description": "<?php echo $description; ?>",
        "image": "https://gdoop.us/en/view.png",
        "sameAs": [
            "https://www.facebook.com/yourpage",
            "https://twitter.com/yourtwitterhandle",
            "https://www.linkedin.com/company/gdoop"
        ]
    }
</script>

<!-- Robots Meta (Indexing Instructions for Search Engines) -->
<meta name="robots" content="index, follow">


<style>
    :root {
        /* --primary: <?php echo $primaryColor; ?>; */
        --primary: #ff0066;
    }
</style>