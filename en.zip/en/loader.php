<section class="loader">
    <div class="loader-ball"></div>
    <div class="loader-ball"></div>
</section>