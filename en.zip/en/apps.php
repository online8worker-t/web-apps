<div class="apps">
        <div class="container">
            <h3><a class="item-1" target="_blank" href="https://youtube.com/@GdoopStudio">Music</a></h3>
            <h3><a class="item-1" target="_blank" href="https://gdoop.us/freelancing">Freelancing</a></h3>
            <h3><a class="item-1" target="_blank" href="https://gdoop.us/careers">Careers</a></h3>
            <h3><a class="item-1" target="_blank" href="https://gdoop.us/studio/licenses">Licenses</a></h3>
            <h3><a class="item-1" target="_blank" href="https://gdoop.us/@ravindu">Ravindu</a></h3>
        </div>
        <div class="container"  id="itemGrid">
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" class="close-btn" width="24" height="24" viewBox="0 0 24 24"><path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/></svg>
    </div>