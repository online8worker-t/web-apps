<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="shortcut icon" href="favicon.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Share - Gdoop</title>
    <link rel="stylesheet" href="style.css?v=1.1">
</head>

<body>
    <?php include_once('header.php') ?>

    <div class="container go-code">
        <input id="code" type="text" placeholder="Code">
        <div class="go-btn">Go</div>
    </div>
    

    <div class="container">
        <form id="cvForm">
            <div class="form-group">
                <label for="fullName">Title</label>
                <input type="text" id="fullName" name="fullName" required value=<?php echo uniqid('Title_'); ?>>
            </div>

            <div class="form-group">
                <label for="experience">Text</label>
                <textarea id="experience" name="experience" rows="6"></textarea>
            </div>

            <button type="submit" class="generate-btn">Generate Text</button>
        </form>

        <div id="qrResult" class="hidden">
            <div id="qrCode"></div>
            <p><b>Scan/download</b> QR or <b>copy/remember/write down</b> URL to view information.</p>
            <a id="cvLink" href="#" target="_blank">View Your CV Online</a>
            <button id="downloadBtn" class="download-btn">Download QR Code</button>
        </div>
    </div>

    <script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
    <script src="script.js?v=1.1"></script>
</body>

</html>