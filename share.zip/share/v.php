<?php
// Check if CV parameter is provided
if (!isset($_GET['i'])) {
    header("HTTP/1.0 404 Not Found");
    die("Data not specified");
}

$filename = basename($_GET['i']);
$filepath = 'data/' . $filename;

// Check if file exists
if (!file_exists($filepath)) {
    header("HTTP/1.0 404 Not Found");
    die("Data not found");
}

// Read and decode the CV data
$cvData = json_decode(file_get_contents($filepath), true);

// Set the page title
$pageTitle = $cvData['fullName'] . " - Gdoop QR Generator";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="shortcut icon" href="favicon.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            line-height: 1.6;
            color: #000;
            background: #f5f5f5;
        }

        h1 {
            border-bottom: 2px solid #ff5e00;
            font-size: 1.4rem;
            margin-bottom: 1rem;
        }

        .section {
            padding: 1rem;
            margin: 0 auto;
            background: #fff;
            border-radius: 1rem;
            max-width: 800px;
        }

        .contact-info {
            margin-bottom: 30px;
        }

        .contact-info p {
            margin: 5px 0;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.5rem 1rem;
        }

        header .app-name {
            font-size: 1.4em;
            font-weight: 600;
        }

        svg {
            border-radius: 50%;
            background: #000;
            width: 40px;
            height: 40px;
            padding: 0.5rem;
            fill: #fff;
        }

        header .app-name {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        header img {
            width: 35px;
            border-radius: 50%;
        }
    </style>
</head>

<body>
    <?php include_once('header.php') ?>
    <br>
    <div class="section">
        <h1><?php echo htmlspecialchars($cvData['fullName']); ?></h1>

        <?php if (!empty($cvData['experience'])): ?>
            <div>
                <p><?php echo nl2br(htmlspecialchars($cvData['experience'])); ?></p>
            </div>
        <?php endif; ?>
    </div>
</body>

</html>