<header>
    <p class="app-name"><img src="./favicon.png" alt="">Gdoop Share</p>
    <a href="https://gdoop.us/share" target="_blank">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
            <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
        </svg>
    </a>
</header>