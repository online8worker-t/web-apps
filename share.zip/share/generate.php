<?php
header('Content-Type: application/json');

// Create data directory if it doesn't exist
if (!file_exists('data')) {
    mkdir('data', 0755, true);
}

// Get the POST data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Invalid data received']);
    exit;
}

// Generate a unique filename
$filename = rand(1, 10000);
$filepath = 'data/' . $filename;

// Save the data to a JSON file
if (file_put_contents($filepath, json_encode($data)) === false) {
    echo json_encode(['success' => false, 'message' => 'Failed to save data']);
    exit;
}

// Generate the URL
$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
$url = $baseUrl . dirname($_SERVER['PHP_SELF']) . '/v?i=' . urlencode($filename);

// Return success with the URL
echo json_encode([
    'success' => true,
    'filename' => 'gdoop--qr-' . $data['fullName'] . '.png',
    'url' => $filename
]);
?>