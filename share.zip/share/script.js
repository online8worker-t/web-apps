document.getElementById('cvForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get form data
    const formData = new FormData(this);
    const data = {};
    formData.forEach((value, key) => {
        data[key] = value;
    });
    
    // Send data to server
    fetch('generate.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            displayQRCode(data.filename, data.url);
        } else {
            alert('Error generating QR code: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while generating the QR code.');
    });
});

function displayQRCode(filename, url) {
    // Clear previous QR code
    document.getElementById('qrCode').innerHTML = '';
    
    // Generate new QR code
    new QRCode(document.getElementById('qrCode'), {
        text: url,
        width: 150,
        height: 150,
        colorDark: "#090086",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
    });
    
    // Set the CV link
    document.getElementById('cvLink').href = 'v?i=' + url;
    document.getElementById('cvLink').textContent = url;
    
    // Set up download button
    document.getElementById('downloadBtn').onclick = function() {
        downloadQRCode(filename);
    };
    
    // Show the result section
    document.getElementById('qrResult').classList.remove('hidden');
}

function downloadQRCode(filename) {
    const qrCodeImg = document.getElementById('qrCode').querySelector('img');
    if (qrCodeImg) {
        const link = document.createElement('a');
        link.href = qrCodeImg.src;
        link.download = filename || 'my-cv-qr.png';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}




// go-code
document.querySelector('.go-btn').addEventListener('click', () => {
    const code = document.getElementById('code').value;
    window.location.href = `https://gdoop.us/share/v?i=${code}`;
})