const CACHE_NAME = 'hnde-triangle--cache-v1';
const BASE_PATH = '/hnde-triangle/';
const urlsToCache = [
  BASE_PATH,
  BASE_PATH + 'index.php',
  BASE_PATH + 'index.css',
  BASE_PATH + 'index.js',
  BASE_PATH + 'favicon.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => response || fetch(event.request))
  );
});

self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});