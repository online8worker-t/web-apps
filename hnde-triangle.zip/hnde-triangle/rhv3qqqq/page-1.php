<style>
    .form-container {
        margin: 0 auto;
        max-width: 700px;
    }

    .form {
        display: flex;
        flex-direction: column;
        width: 100%;
        padding: 1rem;
    }

    h1 {
        text-align: center;
        font-size: 24px;
        margin-bottom: 20px;
    }

    label {
        font-size: 14px;
        display: block;
        margin-bottom: 0.2rem;
        color: var(--font-color-0);
    }

    input,
    select {
        margin-bottom: 0.5rem !important;
    }

    button {
        width: 100%;
        padding: 12px;
        font-size: 16px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .btn-0 {
        margin-left: 0 !important;
    }
</style>
</head>

<body>

    <div class="form-container">
        <form class="form" id="form">

            <h1 class="intro-title" style="font-size: 1.2em; padding-bottom: 1rem;"><i class="fa fa-eye" aria-hidden="true" onclick="pagePreview()"></i></h1>

            <label for="type">type</label>
            <select name="type" id="type">
                <option value="ASSIGNMENT">Assigment</option>
                <option value="EXPERIMENT">Experiment</option>
                <option value="PRACTICAL">Practical</option>
                <option value="PROJECT">Project</option>
            </select>

            <label for="no">Number</label>
            <select name="no" id="no">
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
                <option value="13">13</option>
                <option value="14">14</option>
                <option value="15">15</option>
            </select>

            <label for="subject">Subject</label>
            <input type="text" id="subject" name="subject">

            <label for="subject-code">Subject code</label>
            <input type="text" id="subject-code" name="subject-code">

            <br>
            <br>

            <label for="title">Title</label>
            <input type="text" id="title" name="title">

            <label for="instructor">Instructor</label>
            <input type="text" id="instructor" name="instructor" placeholder="MRS. A.B. RATHNAYAKE">

            <label for="group">Group</label>
            <input type="text" id="group" name="group" placeholder="C05">

            <label for="members">Group Members (comma separated)</label>
            <input type="text" id="members" name="members" placeholder="011,014,134,152">

            <br>
            <br>

            <label for="regNo">Registration Number</label>
            <input type="text" id="regNo" name="regNo" value="" placeholder="COL/CE/2020/F/XXX" required>

            <label for="name">Name</label>
            <input type="text" id="name" name="name" value="" placeholder="A.B.C. PERERA">


            <label for="course">Course</label>
            <select name="course" id="course">
                <option value="HNDCE">HNDCE</option>
                <option value="HNDQS">HNDQS</option>
                <option value="HNDME">HNDME</option>
                <option value="HNDBSE">HNDBSE</option>
                <option value="HNDEEE">HNDEEE</option>
            </select>

            <label for="dateOfIns">Date of Instruction</label>
            <input type="date" name="dateOfIns" id="dateOfIns">

            <label for="dateOfSub">Date of Submission</label>
            <input type="date" id="dateOfSub" name="dateOfSub">

            <br>
            <br>

            <button type="submit" class="btn-0">Download PDF</button>
        </form>
    </div>

    <section id="section-1">
        <div class="container">
            <img class="cover-page" src="./assets/cover-page_.png" alt="cover-page">
            <svg onclick="closePagePreview()" class="close-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path class="close-icon-path" fill="#000" d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z" />
            </svg>
        </div>
    </section>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="./index.js?v=1.0.1"></script>
   

</body>