<footer>
    <div class="container">
        <center class="copyrights">
            <div class="info">
                <a href="privacy-policy">Privacy Policy</a> | 
                <a href="terms-and-conditions">Terms & Conditions</a> | 
                <a href="about">About</a> |
                <a href="contact">Contact</a>
            </div>
            <!-- <p>HNDE | 31<sup>st</sup> Batch | Colombo 15</p> -->
            <a href="https://gdoop.us/uni-triangle">&copy<?php echo date("Y") ?> Report Helper</a>
            <a href="https://gdoop.us"><h3>Powered by Gdoop Studio.</h3></a>
        </center>
    </div>
</footer>