

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="shortcut icon" href="./favicon.png">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Make a cover page for your assignments, practicals or experiments. A cover page can be generated for assignments, practicals and experiments. Made for HNDE students in Sri Lanka. About.">
    <meta name="keywords" content="HNDE, hnde, cover page, ravindu, madhushankha, gdoop, assignments, practicals, experiments, about">
    <link rel="canonical" href="https://gdoop.us/hnde-cp/privacy-policy">

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Contact - HNDE Cover Page Maker</title>
    <link rel="stylesheet" href="./assets/style2.css?v=1.2.8">
    <link rel="stylesheet" href="./assets/fonts.css">
    <script src="./assets/app.js?v=1.2.2" defer></script>

    <style>
        .item-1 h1 {
            font-size: 2.4em;
        }
        .item-1 h3 {
            margin: 1rem 0;
        }
        .item-1 p, h2 {
            margin: 1rem 0;
        }
        .item-1 a {
            color: var(--primary-color);
        }
    </style>
</head>

<body>

    <?php require_once 'header.php' ?>

    <section id="section-0">
        <div class="container">
            <div class="item-1">
                <h1>Contact</h1>
                <p>If you have any questions, You can contact me:</p>
                <ul>
                    <li>
                        <p>By email: support@gdoop.us</p>
                    </li>
                    <li>
                        <p>By visiting my website: <a href="https://gdoop.us" rel="external nofollow noopener" target="_blank">https://gdoop.us</a></p>
                    </li>
                </ul>
            </div>
        </div>
    </section>

    <?php require_once 'footer.php' ?>