

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="description" content="Make a cover page for your assignments, practicals or experiments. A cover page can be generated for assignments, practicals and experiments. Made for HNDE students in Sri Lanka. About.">
    <meta name="keywords" content="HNDE, hnde, cover page, ravindu, madhushankha, gdoop, assignments, practicals, experiments, about, owner, founder, ravindu, madhushankha, gdoop, hnde cover page maker">
    <link rel="canonical" href="https://gdoop.us/hnde-cp/privacy-policy">

    <?php include_once('group-links.php'); ?>

    <title>About - HNDE Cover Page Maker</title>

    <style>
        .item-1 h1 {
            font-size: 2.4em;
        }
        .item-1 h3 {
            margin: 1rem 0;
        }
        .item-1 p, h2 {
            margin: 1rem 0;
        }
        .item-1 a {
            color: var(--primary-color);
        }
    </style>
</head>

<body>

<?php require_once 'header.php' ?>

    <section class="about-page" id="section-0">
        <div class="container">
            <div class="item-1">
                <h1>About</h1>
                <div class="avatar">
                <img  class="owner-avatar" src="./assets//owner.jpg" alt="owner founder ravindu madhushankha gdoop hnde cover page maker">
                </div>
                <p>Hey! My name is Ravindu Madhushankha. I'm a Full Stack Web Developer. Also I'm a student of 31st Batch in HNDE Mattakkuliya.</p>
                <p>I woke up one day and realized that I need to make my cover pages for assignments, practicals, and experiments more easier way. This realization became my contribution to that belief. So I made this Cover Page Maker and publish it for everyone.</p>
                <p>And I'm here to maintain this cover page maker. If you have any problems about this tool, feel free to <a href="https://gdoop.us/@ravindu">contact me</a> anytime.</p>
            </div>
        </div>
    </section>

<?php require_once 'footer.php' ?>