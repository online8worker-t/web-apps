<?php

session_start();

if ($_SESSION['goto'] != date('Y-m-d--h')) {
    header('Location: https://gdoop.us/hnde-cp');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="description" content="Make a cover page for your assignments, practicals or experiments. A cover page can be generated for assignments, practicals and experiments. Made for HNDE students in Sri Lanka.">
    <meta name="keywords" content="HNDE, hnde, cover page, ravindu, madhushankha, gdoop, assignments, practicals, experiments">
    <link rel="canonical" href="https://gdoop.us/hnde-cp/">

    <?php include_once('group-links.php'); ?>


    <title>HNDE Cover Page Maker - Create your report more easier for assignments, practicals and experiments.</title>

</head>

<body>
    <?php require_once 'header.php' ?>

    <main>
        <?php require_once('page-1.php') ?>

    </main>

    <?php require_once 'footer.php' ?>


</body>

</html>