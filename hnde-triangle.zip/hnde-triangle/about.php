<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>About - <?php echo $appName; ?></title>
    <style>
        nav,
        .add-btn,
        .sidebar,
        .menu-btn {
            display: none;
        }
    </style>
</head>

<body>

    <?php include_once('header.php') ?>

    <section class="store">
        <div class="container">
            <div class="item">
            <h1 class="title">HNDE Triangle</h1>
                <div class="details">
                    <p>Your one-stop platform designed exclusively for HNDE students!</p>
                    <br>
                    <p>Whether you're looking to find helpful study resources, and sell your products, explore music, movies, or series, this website has it all. Stay updated with special news, dive into tutorials, and even access tools like a cover page maker, birthday card creator, CV maker, and QR generator.</p>
                    <br>
                    <p>It's your go-to space for entertainment, productivity, and collaboration, all in one place. Enjoy and make the most out of your higher education experience!</p>
                    <br>
                    <br>
                    <p>From Gdoop.</p>
                    <a class="link-0" href="https://gdoop.us">www.gdoop.us &RightArrow;</a>
                </div>
                <div class="details">
                    <br>
                    <p>Developer & Designer:</p>
                    <a class="link-0" href="https://gdoop.us/@ravindu">Ravindu Madhushankha &rightarrow;</a>
                    <br>
                    <br>
                    <p>Copyright &copy; 2022 - <?php echo date('Y') ?> Gdoop. All Right Reserved.</p>
                </div>
            </div>
        </div>
    </section>

</body>

</html>