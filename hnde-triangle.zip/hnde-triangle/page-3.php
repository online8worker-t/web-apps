
    <style>
        nav .btn-1:nth-child(4) {
            border-bottom: 4px solid var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem;
        }

        nav .btn-1:nth-child(4) svg {
            fill: var(--primary) !important;
        }
    </style>

    <section class="posts page">
        <div class="container">
            <a target="_blank" class="example" href="https://wa.me/+94765395434?text=Requesting to sell a product.">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
            </svg>
            <p>Sell your product here</p>
        </a>
            <br>
            <p style="text-align: center;">No products yet</p>
    </section>