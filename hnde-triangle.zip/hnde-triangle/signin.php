<style>
    .welcome-logo {
        width: 100px;
        margin-bottom: 1rem;
    }

    .signin-page {
        width: 100%;
        height: 120vh;
        z-index: 10;
        position: fixed;
        top: -4rem;
        left: 0;
        background: var(--bg-02);
        display: none;
        overflow: hidden;
    }


    .signin-page .container {
        max-width: 340px;
        margin: 0 auto;
        padding: 1rem;
        margin-top: 8rem;
    }

    .sign-in-form input {
        border-radius: 50px;
        border: none;
        width: 100%;
        color: var(--bg-00);
        background: var(--bg-03);
        padding: 1rem;
        width: 100%;
    }

    .sign-in-form {
        display: flex;
        flex-direction: column;
        gap: 1rem;
        align-items: center;
    }

    .sign-in-form .msg {
        color: red;
        display: none;
        font-size: 0.8em;
    }

    .sign-in-form .msg.show {
        display: block;
    }

    .sign-in-form .btn-2 {
        background: var(--primary);
        color: #fff;
        padding: 0.7rem 2rem;
        font-family: var(--ff);
        font-size: 1em;
        width: 100%;
        border-radius: 50px;
        font-weight: 500;
        cursor: pointer;
    }

    .sign-in-form .btn-3 {
        color: var(--bg-00);
        font-size: 0.9em;
        text-decoration: none;
    }

    .from {
        text-align: center;
        font-size: 0.8em;
    }

    .signin-page .owner-info {
        display: flex;
        justify-content: center;
        padding: 0 1rem;
    }
    .signin-page .owner-info a {
        text-decoration: none;
        font-size: 0.9em;
        color: #858585;
    }

    .from h2 {
        font-size: 1.5em;
    }

    @media screen and (max-width: 800px) {
        .signin-page {
            top: -7rem;
        }
    }
</style>

<section class="signin-page">
    <div class="container">
        <form action="" class="sign-in-form">
            <img src="./favicon.png<?php echo $version; ?>" class="welcome-logo" alt="hnde triangle gdoop">
            <input type="password" id="key" placeholder="Enter the secret key">
            <div class="msg">Wrong key.</div>
            <input type="submit" class="btn-2" value="Log in">
            <a href="contact<?php echo $version; ?>" class="btn-3">I don't have the key</a>
            <br>
            <br>
            <div class="from">
                <p>From</p>
                <h2>Gdoop.</h2>
            </div>
        </div>
    </form>
    <div class="owner-info">
        <a target="_blank" href="about<?php echo $version; ?>">About</a>
        <a target="_blank" href="contact<?php echo $version; ?>">Contact</a>
        <a target="_blank" href="https://gdoop.us/@ravindu?from=ht">Developer</a>
        <a target="_blank" href="https://gdoop.us/studio?from=ht">Copyright</a>
        <a target="_blank" href="terms<?php echo $version; ?>">Terms & conditions</a>
        <a target="_blank" href="terms<?php echo $version; ?>">Privacy policy</a>
        <a target="_blank" href="contact<?php echo $version; ?>">Support</a>
        <a target="_blank" href="https://gdoop.us/@ravindu/feedback?from=ht">Feedback</a>
    </div>
    <br>
    <br>
    <br>

    </div>
</section>