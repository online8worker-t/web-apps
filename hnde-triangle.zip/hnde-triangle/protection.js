(function () {
    function blockDevTools() {
        // This attempts to detect debugging by checking execution time
        const start = new Date().getTime();
        debugger;
        const end = new Date().getTime();
    }

    setInterval(blockDevTools, 100);
})();