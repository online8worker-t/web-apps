<?php include_once('links.php') ?>

<section class="resources page">
        <div class="container">
            <div class="item">
                <img src="./assets/cover-1.png<?php echo $version; ?>" alt="gdoop hnde triangle">
            </div>
            <div class="item">
                <h2>Movies & Series</h2>
                <a target="_blank" href="https://stagatv.com">Stagatv.com - Free download (480p, less MB)</a>
                <a target="_blank" href="https://netnaija.xyz">Netnaija - Free download (480p, less MB)</a>
                <a target="_blank" href="https://zoom.lk">Download Sinhala Subtitles</a>
            </div>
            <div class="item">
                <h2>Music</h2>
                <a target="_blank" href="https://youtube.com/@GdoopStudio">Gdoop Music</a>
                <a target="_blank" href="https://www.youtube.com/watch?v=lGCo8ILvauI&list=PLlwUXwIXe0-hDIfnNGMvMPJGVNnTIH-PJ">Musical shows (Youtube)</a>
                <a target="_blank" href="https://afrihag.co.za">Free download music</a>
            </div>
            <div class="item">
                <h2>Images</h2>
                <a target="_blank" href="https://gdoop.us/image-gallery">Download Copyrights Free Images</a>
                <a target="_blank" href="https://gdoop.us/image-resizer">Image Resizer</a>
            </div>
            <div class="item">
                <h2>Learn</h2>
                <a target="_blank" href="https://w3schools.com">W3Schools.com - Programming</a>
                <a target="_blank" href="https://www.youtube.com/@DPEducationLanguageSchool/playlists">
                DP Education - Language School</a>
            </div>
        </div>
    </section>

    <style>
        nav .btn-1:nth-child(2) {
            border-bottom: 4px solid var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem;
        }

        nav .btn-1:nth-child(2) svg {
            fill: var(--primary) !important;
        }
    </style>