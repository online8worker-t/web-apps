<?php include_once('links.php') ?>

<style>
    .page {
        display: none;
    }

    .page.active {
        display: block;
    }

    nav .btn-1:nth-child(1) {
        border-bottom: 4px solid var(--primary);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0.5rem;
    }

    nav .btn-1:nth-child(1) svg {
        fill: var(--primary) !important;
    }

    .banner-background {
        padding: 0.5rem 1rem 1rem;
    }

    .banner {
        max-width: 500px;
        margin: 0 auto;
        padding: 1rem;
        border-radius: 0.5rem;
        font-size: 1.2em;
        color: var(--fc-00);
        background: var(--bg-03);
        font-style: italic;
    }

    .special-4 {
        background: var(--bg-02);
        display: flex;
        flex-direction: column;
        padding: 1rem 1rem 0 1rem;
        text-decoration: none;
        font-size: 0.8rem;
        color: #858585;
    }

    .quick-shortcuts {
        background: rgba(126, 126, 126, 0) !important;
        backdrop-filter: blur(0px);
    }

    @media screen and (max-width: 460px) {
        .quick-shortcuts {
            top: -6rem;
        }
        .special-4 {
            font-size: 0.7rem;
        }
    }
</style>

<div class="page">

    <section class="posts">


        <?php

        include_once('rhv2/config.php');

        mysqli_set_charset($conn, "utf8mb4");

        $query = mysqli_query($conn, "SELECT * FROM hnde_triangle WHERE id = 1");

        if (mysqli_num_rows($query) > 0) {
            while ($row = mysqli_fetch_assoc($query)) {
                if ($row['notice'] == '') {
                } else {
                    echo '<div class="banner-background">';
                    echo '<div class="banner">';
                    echo '<h1>' . $row['notice'] . '</h1>';
                    echo '</div>';
                    echo '</div>';
                }
            }
        }

        ?>

        <div class="cover">
            <img src="./assets/cover.png<?php echo $version; ?>" alt="hnde cover page maker. report helper. gdoop">
        </div>

        <div class="container quick-shortcuts">
            <div class="post">
                <h4>Quick shortcuts</h4>
            </div>

            <a href="https://gdoop.us/hnde-cp<?php echo $version; ?>" class="example special-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
                </svg>
                <p>Create a report cover page</p>
            </a>

            <a onclick="loadPage(2)" class="example special-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <path d="M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM9 4h2v5l-1-.75L9 9V4zm9 16H6V4h1v9l3-2.25L13 13V4h5v16z" />
                </svg>
                <p>Study resourses</p>
            </a>

            <a target="_blank" href="https://youtube.com/@GdoopStudio" class="example">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <path d="m12 3 .01 10.55c-.59-.34-1.27-.55-2-.55a4.001 4.001 0 1 0 0 8c2.22 0 3.99-1.79 3.99-4V7h4V3h-6zm-1.99 16c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z" />
                </svg>
                <p>Listen Music - No lyrics, only vibes.</p>
            </a>

            <a target="_blank" href="https://stagatv.com?from=gdoop" class="example">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <path d="M19 9h-4V3H9v6H5l7 7 7-7zm-8 2V5h2v6h1.17L12 13.17 9.83 11H11zm-6 7h14v2H5z" />
                </svg>
                <p>Download Movies & Series</p>
            </a>

            <a target="_blank" href="https://w3schools.com/?from=gdoop" class="example">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <path d="M9.4 16.6 4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0 4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z" />
                </svg>
                <p>Learn programming</p>
            </a>

            <a target="_blank" href="https://chat.whatsapp.com/KMmHuvPgbGHCSe6VlKfGPs" class="example special-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <path d="M9 13.75c-2.34 0-7 1.17-7 3.5V19h14v-1.75c0-2.33-4.66-3.5-7-3.5zM4.34 17c.84-.58 2.87-1.25 4.66-1.25s3.82.67 4.66 1.25H4.34zM9 12c1.93 0 3.5-1.57 3.5-3.5S10.93 5 9 5 5.5 6.57 5.5 8.5 7.07 12 9 12zm0-5c.83 0 1.5.67 1.5 1.5S9.83 10 9 10s-1.5-.67-1.5-1.5S8.17 7 9 7zm7.04 6.81c1.16.84 1.96 1.96 1.96 3.44V19h4v-1.75c0-2.02-3.5-3.17-5.96-3.44zM15 12c1.93 0 3.5-1.57 3.5-3.5S16.93 5 15 5c-.54 0-1.04.13-1.5.35.63.89 1 1.98 1 3.15s-.37 2.26-1 3.15c.46.22.96.35 1.5.35z" />
                </svg>
                <p>Join the HNDE Triangle WhatsApp group – <span style="font-size: 0.7em;">Send feedback, problems, and share suggestions.<span></p>
            </a>

            <a target="_blank" href="https://gdoop.us/@ravindu?from=ht" class="special-4">
                <!-- <p>Credit:</p> -->
                <p>Created by Ravindu Madhushankha.</p>
                <!-- <p>(Student of 31<sup>st</sup> Batch | HNDE Colombo 15)</p> -->
                <p>Software Developer & Designer at Gdoop.</p>
                <p>www.gdoop.us/@ravindu</p>
                <br>
            </a>

        </div>
    </section>


    <script>
        window.addEventListener('load', () => {
            document.querySelector('.page').classList.add('active');
        })
    </script>

</div>