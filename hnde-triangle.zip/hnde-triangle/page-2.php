
    <style>
        nav .btn-1:nth-child(3) {
            border-bottom: 4px solid var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem;
        }

        nav .btn-1:nth-child(3) svg {
            fill: var(--primary) !important;
        }
    </style>

    <section class="resources page">

        <div class="container">
            <h2>Notes & Past Papers</h2>
            <br>
            <div class="item">
                <p>&bullet; Civil Engineering</p>
                <a target="_blank" href="https://drive.google.com/drive/folders/17_4fGOMmorSbxSu0QCKBGk_ZnseGQFu6?usp=share_link">32 batch</a>
                <a target="_blank" href="https://drive.google.com/folderview?id=17yrD-TujomFuhhJENy_qg6fq9T9sbFci">31 batch</a>
                <a target="_blank" href="https://drive.google.com/drive/folders/1-0ZFfG7hb3Ea27S3QC9tsldsJfTxhnmZhttps://drive.google.com/drive/folders/1-0ZFfG7hb3Ea27S3QC9tsldsJfTxhnmZ">30 batch</a>
            </div>
            <div class="item">
                <p>&bullet; Quantity Surveying</p>
                <a target="_blank" href="https://drive.google.com/drive/folders/1YATZzlh3_3N0npB4U3Iqg4JHaPS5bZ2u">1st Year 1st Semester</a>
                <a target="_blank" href="https://drive.google.com/drive/folders/18y3VeOH5bFbHPlj14-xG8BO3sw00P_mn">1st Year 2nd Semester</a>
                <a target="_blank" href="https://drive.google.com/drive/folders/1XSKNo2M-V9susELgy4pNNINOHJd_SGLj">2nd Year 1st Semester</a>
                <a target="_blank" href="https://drive.google.com/drive/folders/1MZY39VzZJSV04piQ8eJzV7pb2UYHL1C3">2nd Year 2nd Semester</a>
            </div>
            <div class="item">
                <p>&bullet; Mechanical Engineering</p>
                <a target="_blank" href="https://drive.google.com/drive/folders/13tvUKciX-PaoWzTIHrVrJZIOpsj5GNVs">Mechanical</a>
                <a target="_blank" href="https://drive.google.com/drive/folders/1Po1NRqv1lrt9GU57fNO12xnub2r96VCY">30 batch</a>
            </div>
            <div class="item">
                <p>&bullet; Building Services Engineering</p>
                <a target="_blank" href="https://drive.google.com/drive/folders/1ANuvG3jXhGeHmJkdaEKLu54X46--W2-v?usp=sharing">HNDBSE Notes</a>
                <a target="_blank" href="https://drive.google.com/drive/folders/1w4uqS1zZxwufHjTt26OKAcDNoVXTEJNr">2nd Year 2nd Semester</a>
                <a target="_blank" href="https://drive.google.com/drive/folders/1o0IboW-WyXUW_ZE-hk4tTOzkcJQ2haBQ">2nd Year</a>
            </div>
            <div class="item">
                <p>&bullet; Electrical and Electronic Engineering</p>
                <a target="_blank" href="https://drive.google.com/folderview?id=1-6v9SUVdQ42Vr3fFPBi18-NfsXhZMGz6">Electrical and Electronic Engineering</a>
            </div>
        </div>
    </section>
