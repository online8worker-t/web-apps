<?php $imgLink = 'https://gdoop.us/studio/projects/apps/' ?>


<style>
    nav .btn-1:nth-child(5) {
        border-bottom: 0px solid transparent;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0.5rem;
    }
    .notification-alert {
        top: 0.3rem;
    }
</style>

<section class="add page">
    <div class="container">
        <a href="https://gdoop.us/l">
            <img src="<?php echo $imgLink ?>link-shorter.png" alt="gdoop tools">
            <p>Short a long link - Gdoop Link Shorter</p>
        </a>
        <a href="https://gdoop.us/bd-m">
            <img src="<?php echo $imgLink ?>bd-m-logo.png" alt="gdoop tools">
            <p>Create a birthday card - Gdoop B'day Card Maker</p>
        </a>
        <a href="https://gdoop.us/cv-maker">
            <img src="<?php echo $imgLink ?>cv-maker.png" alt="gdoop tools">
            <p>Create a CV(Resume) - Gdoop CV Maker</p>
        </a>
        <a href="report-helper/">
            <img src="<?php echo $imgLink ?>hnde-report-helper.png" alt="gdoop tools">
            <p>Create a cover page - HNDE Report Helper by Gdoop</p>
        </a>
        <a href="https://gdoop.us/tools/qr">
            <img src="<?php echo $imgLink ?>qr-generator.png" alt="gdoop tools">
            <p>Generate a QR code (Personal or Business) - Gdoop QR Generater</p>
        </a>
        <a href="https://gdoop.us/share">
            <img src="<?php echo $imgLink ?>gdoop-share.png" alt="gdoop tools">
            <p>See your important texts anytime, anywhere using any device - Gdoop Share</p>
        </a>
        <a href="https://gdoop.us/image-gallery">
            <img src="<?php echo $imgLink ?>image-gallery.png" alt="gdoop tools">
            <p>Download copyright free images - Gdoop Gallery</p>
        </a>
        <a href="https://gdoop.us/wa">
            <img src="<?php echo $imgLink ?>wa-linca.png" alt="gdoop tools">
            <p>Generate whatsapp link with text and share for anyone - Gdoop WA Linca</p>
        </a>
        <a href="https://wa.me/+94765395434?text=Requesting to add a post.">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
            </svg>
            <p>Add a post to HNDE Triangle (Send details via WhatsApp)</p>
        </a>
        <a href="https://wa.me/+94765395434?text=Requesting to sell a product.">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
            </svg>
            <p>Sell a product on HNDE Triangle (Send details via WhatsApp)</p>
        </a>
    </div>
</section>