<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Donate - <?php echo $appName; ?></title>
</head>

<body>

    <style>
         nav,
        .add-btn {
            display: none;
        }

        .donate .container {
            padding: 1rem;
            display: flex;
            flex-direction: column;
            gap: 1rem;
            font-size: 1em;
            max-width: 600px;
            margin: 0 auto;
        }
    </style>

    <?php include_once('header.php') ?>


    <section class="donate">
        <div class="container">
            <div>
                <h2>Donate Us</h2>
            </div>
            <div>
                <p>Do you know this <b>Website</b> costs us<b></b> to keep it <b>free?</b></p>
                <p>Help keep the project alive.</p>
            </div>
            <div>
                <p>BOC Bank</p>
                <p>K Ravindu Madhushankha</p>
                <p>3430898</p>
                <p>Beliatta Branch</p>
            </div>
        </div>
    </section>

</body>

</html>