<?php

$conn = mysqli_connect('localhost', 'gdoopus_root', '6[n{DuiENc7]', 'gdoopus_001');

if (!$conn) {
    echo 'Connection failed';
}
