<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Contact - <?php echo $appName; ?></title>
    <style>
        nav,
        .add-btn,
        .sidebar,
        .menu-btn {
            display: none;
        }
    </style>
</head>

<body>

    <section class="store">
        <div class="container">
            <div class="item">
                <h1 class="title">Any Problem?</h1>
                <div class="details">
                    <br>
                    <p>Contact us:</p>
                    <p>WhatsApp: <a href="https://wa.me/+94765395434">0765395434</a></p>
                    <p>Email: info@gdoop.us</p>
                    <br>
                    <p>Copyright &copy; 2022 - <?php echo date('Y') ?> Report Helper.</p>
                </div>
            </div>
    </section>

</body>

</html>