// window.addEventListener("load", function () {
//     // Check if the page has already been reloaded
//     if (!sessionStorage.getItem("cacheCleared")) {
        
//         // Clear Local Storage
//         localStorage.clear();

//         // Clear Session Storage (Except the reload flag)
//         sessionStorage.clear();
//         sessionStorage.setItem("cacheCleared", "true");

//         // Clear Cookies
//         document.cookie.split(";").forEach(function (c) {
//             document.cookie = c
//                 .replace(/^ +/, "")
//                 .replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
//         });

//         // Reload Page
//         location.reload(true);
//     }
// });


const menuBtn = document.querySelector('.menu-btn')
const sidebar = document.querySelector('.sidebar')

menuBtn.addEventListener('click', () => {
    sidebar.classList.toggle('active')
})


// Preloader
window.addEventListener('load', () => {
    document.querySelector('.loader').classList.add('hide')
    
})



document.addEventListener('DOMContentLoaded', function() {
    // Collect visitor data
    const visitorData = {
        screenWidth: screen.width,
        screenHeight: screen.height,
        browser: detectBrowser()
    };

    // Send data to PHP backend
    fetch('api-0.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(visitorData)
    })
    .then(response => response.json())
    .then(data => {
        // console.log('Visitor data saved:', data);
    })
    .catch(error => {
        console.error('Error:', error);
    });

    // Simple browser detection
    function detectBrowser() {
        const userAgent = navigator.userAgent;
        if (userAgent.includes('Firefox')) return 'Firefox';
        if (userAgent.includes('Safari') && !userAgent.includes('Chrome')) return 'Safari';
        if (userAgent.includes('Chrome')) return 'Chrome';
        if (userAgent.includes('Edge')) return 'Edge';
        if (userAgent.includes('Opera') || userAgent.includes('OPR')) return 'Opera';
        if (userAgent.includes('Trident')) return 'Internet Explorer';
        return 'Unknown';
    }
});



if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/hnde-triangle/sw.js')
        .then(registration => {
          // console.log('ServiceWorker registration successful');
        })
        .catch(err => {
          // console.log('ServiceWorker registration failed: ', err);
        });
    });
  }
  
  
  

// Function to update online/offline status
function updateOnlineStatus() {
const offlineMessage = document.getElementById('offline-message');
if (navigator.onLine) {
offlineMessage.style.display = 'none';
} else {
offlineMessage.style.display = 'block';
}
}

// Initial check
updateOnlineStatus();

// Listen for online/offline events
window.addEventListener('online', updateOnlineStatus);
window.addEventListener('offline', updateOnlineStatus);

// Additional check for service worker support
if ('serviceWorker' in navigator) {
window.addEventListener('load', () => {
navigator.serviceWorker.register('/ghjj-rtyi/sw.js')
.then(registration => {
console.log('SW registered: ', registration.scope);
})
.catch(err => {
console.log('SW registration failed: ', err);
});
});
}