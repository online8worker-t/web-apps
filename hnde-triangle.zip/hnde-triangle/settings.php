<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>
    <title>Settings - <?php echo $appName; ?></title>

    <style>
        nav,
        .add-btn {
            display: none;
        }

        .page .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 1rem;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        form label {
            font-size: 0.9em;
        }

        .sign-in-form input[type="text"],
        .sign-in-form textarea {
            border-radius: 5px;
            border: none;
            color: var(--bg-00);
            background: var(--bg-03);
            padding: 0.5rem;
            width: 100%;
        }

        input[type="color"] {
            border-radius: 5px;
            background: var(--bg-03);
            width: 100%;
        }

        .sign-in-form .msg {
            color: red;
            padding: 1rem;
            display: none;
            font-size: 0.8em;
        }

        .sign-in-form .msg.show {
            display: block;
        }

        .btn {
            text-decoration: none;
        }

        .btn-2 {
            background: var(--primary) !important;
            padding: 0.2rem 1rem;
            font-weight: 500;
            border-radius: 5px;
            width: 100px !important;
            color: #fff;
            border: none;
            outline: none;
            padding: 0.5rem;
        }

        form .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        form textarea {
            font-family: var(--ff);
            resize: vertical;
            height: 100px;
        }

        form .buttons {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
            align-items: center;
        }

        @media screen and (max-width: 1000px) {
            .sidebar {
                left: -100%;
            }

            .sidebar.active {
                left: 0;
            }
        }
    </style>

</head>

<body>

    <?php include_once('header.php') ?>

    <section class="page">
        <div class="container">
            <form action="" class="sign-in-form">

                <div class="form-group">
                    <label for="">Notice</label>
                    <textarea name="" id="notice"></textarea>
                </div>

                <div class="form-group">
                    <label for="">Use this feature to post anonymous notices. It's okay to use it for fun, but please don’t use bad language or blame your friends.</label>
                </div>

                <div class="form-group">
                    <label for="">Colour</label>
                    <input type="color" name="colour" placeholder="#6601ff" id="colour" value="#e60f6c">
                </div>

                <div class="form-group">
                    <label for="">Please avoid using very dark (black) or very light (white) colours, as they may not appear clearly on the screen.</label>
                </div>

                <div class="buttons">
                    <input type="submit" class="btn btn-2" value="Set">
                    <a href="https://gdoop.us/hnde-cp?settings=canceled" class="btn">Cancel</a>
                </div>
                <div class="msg">Error with inputs</div>
            </form>
        </div>
    </section>


    <script>
        document.querySelector('.sign-in-form').addEventListener('submit', e => {
            e.preventDefault()
            // Send data to PHP backend

            const formData = {
                colour: document.querySelector('#colour').value,
                notice: document.querySelector('#notice').value,
            }

            fetch('api-1.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(formData)
                })
                .then(response => response.json())
                .then(data => {
                    // console.log('Changed:', data);
                    location.href = 'https://gdoop.us/hnde-triangle?settings=changed';
                    // location.href = 'http://127.0.0.1/hnde-triangle--6-6-2025';
                })
                .catch(error => {
                    document.querySelector('.msg').classList.add('show');
                    console.error('Error:', error);
                });
        })
    </script>

</body>

</html>