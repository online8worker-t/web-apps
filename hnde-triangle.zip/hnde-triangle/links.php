<?php

header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>

<?php

include_once('rhv2/config.php');

$version = '?co=' . uniqid('');
$primaryColor = '' ?? '#dd1efe';

$query = mysqli_query($conn, "SELECT * FROM hnde_triangle WHERE id = 1");

if (mysqli_num_rows($query) > 0) {
    while ($row = mysqli_fetch_assoc($query)) {
        $primaryColor = $row['colour'];
    }
}

$appName = "HNDE Triangle - Gdoop";

// #dd1e6e

?>

<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="HNDE Triangle From Gdoop">

<meta name="theme-color" content="<?php echo $primaryColor; ?>">

<meta name="description" content="Create your report easily. Post and Sell your products here. Explore Music, Movies, Series, Learning, Reading and more. Made for HNDE students in Sri Lanka.">
<meta name="keywords" content="HNDE, hnde, cover page, ravindu, madhushankha, gdoop, assignments, practicals, experiments, music, series, movies, tutorials, hnde triangle">
<link rel="canonical" href="https://gdoop.us/hnde-triangle">

<link rel="shortcut icon" href="favicon.png<?php echo $version; ?>">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="index.css<?php echo $version; ?>">
<script src="index.js<?php echo $version; ?>" defer></script>
<script src="protection.js<?php echo $version; ?>" defer></script>

<!-- Open Graph (OG) for Social Media Sharing -->
<meta property="og:title" content="<?php echo $appName; ?>.">
<meta property="og:description" content="Create your report easily. Post and Sell your products here. Exporel Music, Movies, Series, Learning, Reading and more. Made for HNDE students in Sri Lanka.">
<meta property="og:image" content="https://gdoop.us/hnde-triangle/assets/view.png">
<!-- Add your preview image URL -->
<meta property="og:url" content="https://www.gdoop.us/hnde-triangle">
<meta property="og:type" content="website">
<meta property="og:site_name" content="HNDE Triangle">

<!-- Schema Markup (Structured Data for Search Engines) -->
<script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": "HNDE Triangle From Gdoop",
        "url": "https://www.gdoop.us/hnde-triangle",
        "description": "Create your report easily. Post and Sell your products here. Exporel Music, Movies, Series, Learning, Reading and more. Made for HNDE students in Sri Lanka.",
        "image": "https://gdoop.us/hnde-triangle/assets/view.png",
        "sameAs": [
            "https://www.facebook.com/yourpage",
            "https://twitter.com/yourtwitterhandle",
            "https://www.linkedin.com/company/gdoop"
        ]
    }
</script>

<!-- Robots Meta (Indexing Instructions for Search Engines) -->
<meta name="robots" content="index, follow">


<style>
    :root {
        --primary: <?php echo $primaryColor; ?>;
    }
</style>