<?php include_once('links.php') ?>

<style>
    nav .btn-1:nth-child(5) {
        border-bottom: 4px solid var(--primary);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0.5rem;
    }

    nav .btn-1:nth-child(5) svg {
        fill: var(--primary) !important;
    }

    .notification-alert {
        display: none;
    }
</style>

<section class="notifications page">
    <div class="container">
    <div class="item">
            <p>What is <?php echo $appName; ?>?</p>
            <a href="about">see more</a>
        </div>
        <div class="item">
            <p><?php echo $appName; ?> has been updated.</p>
        </div>
        <div class="item">
        <p>Join us for daily updates.</p>
        <a target="_blank" href="https://whatsapp.com/channel/0029VaoEzwn8fewtEL1B0D3l">Whatsapp channel</a>
        </div>
    </div>
</section>