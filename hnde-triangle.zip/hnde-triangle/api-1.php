<?php

include_once('rhv2/config.php');
mysqli_set_charset($conn, "utf8mb4");

$jsData = json_decode(file_get_contents('php://input'), true);

$colour = $jsData['colour'] ?? '#ff0066';
$notice = $jsData['notice'] ?? '';
$version = uniqid('');

$sql = mysqli_query($conn, "UPDATE `hnde_triangle` SET `colour`='$colour',`version`='$version', `notice`='$notice' WHERE 1");

// Send response
header('Content-Type: application/json');
echo json_encode(['status' => 'success', 'message' => $version]);

?>