<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="favicon.png" type="image/png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Short your long URL or hide your URL and share. You can customize your short URL.">
    <meta name="keywords" content="link shorter, link shorter with custom name, software, application, apps, tools, ravindu madhushankha, gdoop">
    <link rel="canonical" href="https://gdoop.us/l/">
    <link rel="canonical" href="https://gdoop.us/l/index">
    <meta property="og:type" content="website">
    <meta property="og:image" content="favicon.png">
    <meta property="og:title" content="Gdoop - Link Shorter">
    <meta property="og:description" content="Software applications for people how to do their best in tough conditions and help them evolve their Daily works">
    <title>Link Shorter - Custom Link Generator | Gdoop</title>
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <link rel="stylesheet" href="./assets/index.css?v=1.0.6">
    <link rel="stylesheet" href="./pn/css/intlTelInput.css">
    <script src="./assets/index.js?1.0.6" defer></script>
</head>
<body>
    <!-- <header>
        <div class="container-0">
            <a class="brand" href="https://gdoop.us/wa">Link Short</a>
            <button class="btn-0"><i class="fa-solid fa-circle-question"></i></button>
        </div>
    </header> -->

    <section class="section-0">
        <div class="container">
            <form action="">
                <div class="item">
                    <h1>Short your URL</h1>
                </div>
                <div class="item">
                    <label for="link">URL</label>
                    <input type="text" name="link" placeholder="https://www.corica.online/any-websites-with-long-URLs-What-is-the-purpose-of-creating-such-long-URLs" id="link" required>
                </div>
                <div class="item">
                    <div id="c-n-btn"><i class="fa-solid fa-gear"></i></div>
                </div>
                <div class="item">
                <p class="example">gdoop.us/l/<span>custom-name</span></p>
                    <p id="random-names" for="c-link">Custom Name &nbsp;<i class="fa-solid fa-shuffle"></i></p>
                    <input type="tel" id="c-link" name="c-link" required>
                </div>
                <button id="generate-btn">Generate Link</button>
            </form>
        </div>
    </section>

    <section class="section-1">
        <div class="container">
            <p id="generated-link">gdoop.us/l/ravindu</p>
            <button class="btn-1 copy"><i class="fa-solid fa-clipboard"></i></button>
        </div>
    </section>

    <section class="section-2">
            <p>Generating...</p>
    </section>

    <footer>
        <!-- <a class="developer" href="https://wa.me/+94765395434?text=Hey%20Ravindu!%20From%20Gdoop.">Created by Ravindu Madhushankha</a> -->
        <br>
        <a href="mailto:info@gdoop.us">Contact us: info@gdoop.us</a>
        <br>
        <a href="pages/policy-terms">Policy and Terms</a>
        <p><?php echo date('Y') ?> Link Shorter | <a href="https://gdoop.us">Powered by Gdoop.</a></p>
        <!-- <p>Created by Ravindu Madhushankha</p> -->
    </footer>
</body>
</html>