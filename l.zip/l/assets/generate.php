<?php

sleep(1);

$conn = mysqli_connect('127.0.0.1', 'root', '', 'test');

if (!$conn) {
    echo 'Connection failed';
}





$input = file_get_contents('php://input');
$decoded = json_decode($input, true);

if (isset($_POST)) {
    $link = $decoded['link'];
    $cLink = $decoded['cLink'];
    
    $fileName = $cLink . '.php';
    $content = "<?php header('Location: https://" . $link . "') ?>";

    
    $query = mysqli_query($conn, "INSERT INTO dm01 (username, phone) VALUES ('{$link}', '{$cLink}')");
    
    if (file_exists($fileName)) {
        echo json_encode(['msg' => 'Username already taken']);
    } else {
        file_put_contents($fileName, $content);
        echo json_encode(['msg' => 'Done']);
    }

    // if ($query) {
    //     echo json_encode(['success' => true, 'msg' => 'Done.']);
    // } else {
    //     echo json_encode(['success' => false]);
    // }
}

?>