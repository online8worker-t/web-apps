// Copy to clipboard
const copy = document.querySelector('.copy')
copy.addEventListener('click', async () => {
    await navigator.clipboard.writeText(document.querySelector('.section-1 .container p').innerText)
    alert('Copied.')
})

// Show generated link
document.querySelector('#generate-btn').addEventListener('click', async (e) => {
    document.querySelector('.section-1').classList.remove('active')
    document.querySelector('.section-2').classList.add('active')
    e.preventDefault()

    document.querySelector('.section-2 p').innerText = 'Generating...';
    document.querySelector('.section-2 p').style.color = '#575757';


    // Generate the link
    async function generateLink() {
        const link = document.querySelector('#link').value
        const cLink = document.querySelector('#c-link').value

        console.log(link, cLink)

        await fetch('generate.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                link: link,
                cLink: cLink
            })
        })
            .then((response) => response.json())
            .then(data => {
                document.querySelector('#generated-link').innerText = `gdoop.us/l/${cLink}`
                if (data.msg === 'Username already taken') {
                    document.querySelector('.section-2 p').innerText = data.msg;
                    document.querySelector('.section-2 p').style.color = '#ff0066';
                } else {
                    document.querySelector('.section-1').classList.add('active')
                    document.querySelector('.section-2').classList.remove('active')
                }
                console.log(data.msg)
            })
    }

    generateLink()

})



// generate randome names
function Str_Random(length) {
    let result = '';
    const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
    
    // Loop to generate characters for the specified length
    for (let i = 0; i < length; i++) {
        const randomInd = Math.floor(Math.random() * characters.length);
        result += characters.charAt(randomInd);
    }
    return result;
}

document.querySelector('#c-link').value = Str_Random(4)

const randomNames = document.querySelector('#random-names')
let cLink = document.querySelector('#c-link').value

randomNames.addEventListener('click', () => {
    document.querySelector('#c-link').value = Str_Random(4)
})

// Custom name show hide 
document.querySelector('#c-n-btn').addEventListener('click', () => {
    document.querySelector('.section-0 .container .item:nth-child(4)').classList.toggle('active')
})