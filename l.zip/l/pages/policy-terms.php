<!DOCTYPE html>
<html lang="en">
<head>
<link rel="icon" href="favicon.png" type="image/png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Link Short - Privacy Policy and Terms</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 1rem;
            margin: 0 auto;
            max-width: 900px;
        }

        h2 {
            color: #333;
        }

        p {
            line-height: 1.6;
            margin-bottom: 15px;
        }

        strong {
            color: #555;
        }
    </style>
</head>
<body>

    <h2>Privacy Policy:</h2>
    <p>At Link Short, we are committed to ensuring the privacy and security of your personal information. This Privacy Policy outlines how we collect, use, and protect the data you provide when using our WhatsApp Link Maker Tool. By using our website, you agree to the terms outlined in this policy.</p>

    <h2>Information We Collect:</h2>
    <p>
        <strong>1. Link:</strong> We collect the link you entered.</p>
    <p>
        <strong>2. Custom Name:</strong> The custom name provided is used solely for generating the short link.
    </p>

    <!-- Add more sections as needed -->

    <h2>How We Use Your Information:</h2>
    <p>1. <strong>Short Link Generation:</strong> Your link and custom name are used solely for the purpose of creating a personalized short link as per your specifications.</p>
    <p>2. <strong>Anonymous Analytics:</strong> We may collect anonymous data for analytical purposes to enhance our services and improve user experience. This data does not include personally identifiable information.</p>

    <!-- Add more sections as needed -->

    <h2>Data Security:</h2>
    <p>We prioritize the security of your information. Our website employs industry-standard security measures to protect against unauthorized access, disclosure, alteration, or destruction of the data you provide.</p>

    <h2>Terms of Service:</h2>
    <p>By using our Link Short, you agree to the following terms:</p>
    <p>1. <strong>Accuracy of Information:</strong> You are responsible for providing accurate and up-to-date information when using the tool.</p>
    <p>2. <strong>Prohibited Content:</strong> Users are prohibited from creating WhatsApp links containing offensive, inappropriate, or harmful content.</p>

    <!-- Add more sections as needed -->

    <p>By using our website, you acknowledge that you have read, understood, and agreed to our Privacy Policy and Terms of Service. If you have any questions or concerns, please contact us at info@gdoop.us.</p>

</body>
</html>
