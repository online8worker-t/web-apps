<?php

sleep(1);

$conn = mysqli_connect('localhost', 'gdoopus_root', '6[n{DuiENc7]', 'gdoopus_001');

if (!$conn) {
    echo 'Connection failed';
}





$input = file_get_contents('php://input');
$decoded = json_decode($input, true);

if (isset($_POST)) {
    $username = $decoded['username'];
    $phone = $decoded['phone'];
    $text = $decoded['text'];
    
    $fileName = $username . '.php';
    $content = "<?php header('Location: https://wa.me/" . $phone . "?text=" . $text . "') ?>";

    
    $query = mysqli_query($conn, "INSERT INTO wa (username, phone, text) VALUES ('{$username}', {$phone}, '{$text}')");
    
    if (file_exists($fileName)) {
        echo json_encode(['msg' => 'Username already taken']);
    } else {
        file_put_contents($fileName, $content);
        echo json_encode(['msg' => 'Done']);
    }

    // if ($query) {
    //     echo json_encode(['success' => true, 'msg' => 'Done.']);
    // } else {
    //     echo json_encode(['success' => false]);
    // }
}

?>