<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="./assets/favicon.png" type="image/png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Custom Whatsapp link Maker. Simplify communication and connect seamlessly with friends, family, or clients by creating custom links that instantly open WhatsApp chats.">
    <meta name="keywords" content="wa-link-maker, custom whatsapp link maker, wa, software, application, apps, tools, ravindu madhushankha, gdoop">
    <link rel="canonical" href="https://gdoop.us/wa/">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Whatsapp link maker">
    <meta property="og:description" content="Software applications for people how to do their best in tough conditions and help them evolve their Daily works">
    <title>WA Linca - Custom Whatsapp Link Maker | Gdoop</title>
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <link rel="stylesheet" href="./assets/index.css?v=1.0.2">
    <link rel="stylesheet" href="./pn/css/intlTelInput.css">
    <script src="./pn/js/intlTelInput.js" defer></script>
    <script src="./assets/index.js?1.0.2" defer></script>
</head>
<body>
    <header>
        <div class="container-0">
            <a class="brand" href="https://gdoop.us/wa"><img src="./assets/favicon.png" alt="wa linca main logo">WA Linca</a>
            <button class="btn-0"><i class="fa-solid fa-circle-question"></i></button>
        </div>
    </header>

    <section class="section-0">
        <div class="container">
            <form action="">
                <div class="item">
                    <h1>Simplify communication and connect seamlessly with <span>friends, family,</span> or <span>clients</span> by creating custom links.</h1>
                </div>
                <div class="item">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username" required>
                </div>
                <div class="item">
                    <label for="wa-no">Your Whatsapp Number</label>
                    <input type="tel" id="phone" name="pn" required>
                </div>
                <div class="item">
                    <label for="text">Greeting Text (Optional)</label>
                    <input type="text" id="text" name="text">
                </div>
                <button id="generate-btn">Generate Link</button>
            </form>
        </div>
    </section>

    <section class="section-1">
        <div class="container">
            <p id="generated-link">https://gdoop.us/wa/ravindu</p>
            <button class="btn-1 copy"><i class="fa-solid fa-clipboard"></i></button>
        </div>
    </section>

    <section class="section-2">
            <p>Generating...</p>
    </section>

    <footer>
        <!-- <a class="developer" href="https://wa.me/+94765395434?text=Hey%20Ravindu!%20From%20Gdoop.">Created by Ravindu Madhushankha</a> -->
        <br>
        <a href="mailto:info@gdoop.us">Contact us: info@gdoop.us</a>
        <br>
        <a href="policy-terms">Policy and Terms</a>
        <p><?php echo date('Y') ?> WA Linca | <a href="https://gdoop.us">Powered by Gdoop.</a></p>
    </footer>
</body>
</html>