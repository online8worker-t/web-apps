<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" href="favicon.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Birthday Card Maker - Gdoop</title>
    <link rel="stylesheet" href="index.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.js"></script>
    <script src="./index.js" defer></script>
</head>

<body>
    <header>
        <div class="container">
            <a href="https://gdoop.us/bd-m"><svg class="logo-svg" xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24"><path d="M12 6a2 2 0 0 0 2-2c0-.38-.1-.73-.29-1.03L12 0l-1.71 2.97c-.19.3-.29.65-.29 1.03 0 1.1.9 2 2 2zm4.6 9.99-1.07-1.07-1.08 1.07c-1.3 1.3-3.58 1.31-4.89 0l-1.07-1.07-1.09 1.07C6.75 16.64 5.88 17 4.96 17c-.73 0-1.4-.23-1.96-.61V21c0 .55.45 1 1 1h16c.55 0 1-.45 1-1v-4.61c-.56.38-1.23.61-1.96.61-.92 0-1.79-.36-2.44-1.01zM18 9h-5V7h-2v2H6c-1.66 0-3 1.34-3 3v1.54c0 1.08.88 1.96 1.96 1.96.52 0 1.02-.2 1.38-.57l2.14-2.13 2.13 2.13c.74.74 2.03.74 2.77 0l2.14-2.13 2.13 2.13c.37.37.86.57 1.38.57 1.08 0 1.96-.88 1.96-1.96V12C21 10.34 19.66 9 18 9z"/></svg></a>
            <a href="https://wa.me/+94765395434" class="btn btn-0">
                <svg class="call-svg" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <path
                        d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56a.977.977 0 0 0-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z" />
                </svg>
            </a>
        </div>
    </header>

    <section class="intro">
        <div class="container">
            <h1>Birthday Card Maker.</h1>
            <p>Make a wish for your friend's birthday.</p>
        </div>
    </section>

    <section>
        <form class="container" method="post">
            <div class="item">
                <div class="themes">
                    <p>Choose your template</p>
                    <div class="theme">
                        <input type="radio" id="default" name="theme">
                        <label for="default">Default</label>
                    </div>
                    <div class="theme">
                        <input type="radio" id="red" name="theme">
                        <label for="red">Red (Locked)</label>
                    </div>
                    <div class="theme">
                        <input type="radio" id="sky-blue" name="theme">
                        <label for="sky-blue">Sky Blue (Locked)</label>
                    </div>
                </div>
                <div class="templates">
                    <div class="template"></div>
                </div>
            </div>

            <div class="item avatar-item">
                <input type="file" id="file">
                <div class="form-control">
                    <label for="file" class="btn btn-1">Add Photo</label>
                    <div class="avatar"></div>
                </div>
            </div>

            <div class="item">
                <div class="shift">
                    <a href="#">Basic</a>
                    <a href="#">Advanced (Locked)</a>
                </div>
                <div class="form-control">
                    <label for="">Name</label>
                    <input type="text" id="name" name="name" placeholder="Ravindu">
                </div>
                <div class="form-control">
                    <label for="">Greeting</label>
                    <input type="text" id="greeting" name="greeting" placeholder="Happy Birthday!" value="Happy Birthday!">
                </div>
                <div class="form-control">
                    <label for="">Caption</label>
                    <textarea name="caption" id="caption" rows="3"
                        placeholder="Hope your day is filled with fun, laughter, and all your favorite things.">Hope your day is filled with fun, laughter, and all your favorite things.</textarea>
                </div>
            </div>

            <div class="item submit-item">
                <a id="download" class="btn btn-2">Download Image</a>
            </div>
        </form>
    </section>

    <section class="output-section">
        <div class="container">
            <div class="output" id="output">
                <div class="background">
                    <div class="text-container">
                        <p id="greeting-text">Happy Birthday!</p>
                        <p id="caption-text"><span id="name-text"></span>Hope your day is filled with fun, laughter, and all your favorite things.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="msg-section">
        <div class="container">
            <p>Happy Birthday<br>to you! :)</p>
            <div class="btn btn-2 close-btn">OK</div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>Birthday Card Maker by Gdoop Graphics</p>
            <p>&copy;2024 Gdoop Studio</p>
        </div>
    </footer>
</body>

</html>