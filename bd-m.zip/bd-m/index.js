const name = document.querySelector("#name")
const greeting = document.querySelector("#greeting")
const caption = document.querySelector("#caption")

let nameText = document.querySelector("#name-text")
let greetingText = document.querySelector("#greeting-text")
let captionText = document.querySelector("#caption-text")

const submitBtn = document.querySelector('#download')
const output = document.querySelector('.output')
const msg = document.querySelector('.msg-section')
const msgText = document.querySelector('.msg-section p')
const closeBtn = document.querySelector('.close-btn')

closeBtn.addEventListener('click', () => {
    msg.classList.remove('active')
})

greeting.addEventListener('keyup', () => {
    greetingText.innerHTML = `${greeting.value}`
    autoClick()
    document.querySelector('.output-section .container').style.display = 'hide'
})
caption.addEventListener('keyup', () => {
    captionText.innerHTML = `<span id="name-text">${name.value}, </span>${caption.value}`
    autoClick()
})
name.addEventListener('keyup', () => {
    captionText.innerHTML = `<span id="name-text">${name.value}, </span>${caption.value}`
    autoClick()
})



// download image
function autoClick() {
    document.querySelector('.output-section .container').style.display = 'block'
    //$('#download').click()
    html2canvas(document.querySelector('#output'), {
        onrendered: function (canvas) {
            const imageData = canvas.toDataURL('image/jpg');
            const newData = imageData.replace(/^data:image\/jpg/, "data:application/octet-stream");
            $('#download').attr('download', `happy-birthday-${name.value}--gdoop-graphics.jpg`).attr('href', newData);
            console.log('Loaded.');
        }
    })
}

$('#download').on('click', function () {
    
    //document.querySelector('.output-section .container').style.display = 'block'
    
    // greetingText.innerHTML = `${greeting.value}`
    // captionText.innerHTML = `<span id="name-text">${name.value}, </span>${caption.value}`
    msgText.innerHTML = `Happy Birthday<br>${name.value} :)`

    autoClick()
    sendData()
})

 // sending data to the database ================================================
 function sendData() {

    fetch('send.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: name.value,
            greeting: greeting.value,
            caption: caption.value,
        })
    })
        .then((response) => response.json())
        .then(data => {
            console.log(data.msg)
        })
}

// ==================================================================


