<?php

$conn = mysqli_connect('localhost', 'gdoopus_root', '6[n{DuiENc7]', 'gdoopus_001');

if (!$conn) {
    echo 'Connection failed';
}

$input = file_get_contents('php://input');
$decoded = json_decode($input, true);

if (isset($_POST)) {
    $name = $decoded['name'];
    $greeting = $decoded['greeting'];
    $caption = $decoded['caption'];

    $query = mysqli_query($conn, "INSERT INTO bd_m (greeting, name, caption) VALUES ('{$greeting}', '{$name}', '{$caption}')");

    if ($query) {
        echo json_encode(['success' => true, 'msg' => 'Done.']);
    } else {
        echo json_encode(['success' => false]);
    }
}

?>