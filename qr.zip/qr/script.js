const wrapper = document.querySelector('.wrapper'),
    generateBtn = document.querySelector('.form button'),
    qrInput = document.querySelector('.form input'),
    qrImg = document.querySelector('.qr-code-img')

generateBtn.addEventListener("click", () => {
    let qrValue = qrInput.value
    if (!qrValue) return
    generateBtn.innerText = "Generating QR Code..."
    generateBtn.style.opacity = "0.5";
    qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${qrValue}`
    qrImg.addEventListener("load", () => {
        generateBtn.innerText = "Generate QR Code"
        generateBtn.style.opacity = "1";
        wrapper.classList.add('active')
    })
})

qrInput.addEventListener("keyup", () => {
    if (!qrInput.value) {
        wrapper.classList.remove("active")
    }
})

