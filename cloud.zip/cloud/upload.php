<?php

if(isset($_POST["submit"])) {

    $time = date("d-m-Y--H-i-s");

    $fileName = $_FILES['fileToUpload']['name'];
    $fileName = $time."-".$fileName;

    move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], "files/".$fileName);
    header ('Location: index.php?Done!');
}else{
    echo 'error!';
}

?>
