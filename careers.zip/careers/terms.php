<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms | Careers</title>
    <style>

        body {
            display: flex;
            flex-direction: column;
            max-width: 1000px;
            margin: 2rem auto;
            gap: 1rem;
            padding: 2rem;
        }
        a {
            color: #000;
            font-size: 1.2em;
        }

    </style>
</head>
<body>
    <a href="https://drive.google.com/file/d/1mOeA_i5DJZIpjmW8ymta_7DpoAkuj9NR/view?usp=drivesdk">Employee Agreement</a>
    <a href="https://drive.google.com/file/d/1m8JjU2s_Tv6E7jtZ9Q-dvTKH6gND4VOQ/view?usp=drivesdk">Project Submission Instruction</a>
</body>
</html>