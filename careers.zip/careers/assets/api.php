<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $position = htmlspecialchars(trim($_POST["positions"]));
    $email = trim($_POST["email"]);
    $workingTime = htmlspecialchars(trim($_POST["working-time"]));
    $bankName = trim($_POST["bank-name"]);
    $bankNumber = trim($_POST["bank-number"]);
    $bankBranch = trim($_POST["bank-branch"]);
    $time = date('d-M-Y');
    $filePath = ''; 

    if (!$email || !$workingTime || !$position) {
        echo json_encode(["success" => false, "message" => "All fields are required."]);
        exit;
    }

    if ((isset($_FILES['file']) && $_FILES['file']['error'] == 0)) {
        $uploadedFile = $_FILES['file'];
        $uploadDirectory = 'cv/'; // Ensure this folder exists and is writable
        // $filePath = $uploadDirectory . basename($uploadedFile['name']);
        $filePath = $uploadDirectory . $position . '-' . $time . '--' . basename($uploadedFile['name']);
        move_uploaded_file($uploadedFile['tmp_name'], $filePath);
    }   

    // Format message to store in the text file
    $entry = "CV: $filePath\nEmail: $email\nPosition:\n$position\n$time\nTime: $workingTime----------------------\n";

    // Save to a text file
    $file = "users";
    if (file_put_contents($file, $entry, FILE_APPEND | LOCK_EX)) {
        echo json_encode(["success" => true, "message" => "Request sent successfully!"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to send request."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request."]);
}

?>


