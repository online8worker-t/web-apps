
document.querySelector(".form-1").addEventListener("submit", async function (event) {
    event.preventDefault();

    let formData = new FormData(this);
    // const file = document.getElementById("file").files[0];
    // formData.append("file", file);
    let responseMessage = document.getElementById("responseMessage");

    try {
        let response = await fetch("assets/api.php", {
            method: "POST",
            body: formData
        });

        let result = await response.json();

        if (result.success) {
            responseMessage.style.color = "green";
            this.reset(); // Clear form after successful submission
        } else {
            responseMessage.style.color = "red";
        }

        responseMessage.textContent = result.message;
    } catch (error) {
        responseMessage.style.color = "red";
        responseMessage.textContent = "An error occurred. Please try again.";
    }
});


// positions
fetch('assets/positions')
    .then(response => response.text())
    .then(data => {
        let tools = data.split("\n").filter(tool => tool.trim() !== ""); // Split lines & remove empty ones
        let select = document.getElementById("positions");

        tools.forEach(tool => {
            let option = document.createElement("option");
            option.value = tool.trim();
            option.textContent = tool.trim();
            select.appendChild(option);
        });
    })
    .catch(error => console.error("Error loading:", error));