<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="shortcut icon" href="assets/preview.png">
    <link rel="apple-touch-icon" href="assets/preview.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Careers | Gdoop</title>
    <link rel="stylesheet" href="./assets/index.css?v=1.2">
    <script src="./assets/index.js?v=1.2" defer></script>


    <!-- Open Graph (OG) for Social Media Sharing -->
    <meta property="og:title" content="Join Gdoop as a Freelancer!">
    <meta property="og:description" content="Are you a skilled freelancer looking for exciting opportunities? Grow your freelance career with us. Whether you're into design, writing, programming, or marketing – we welcome passionate individuals from all fields!">
    <meta property="og:image" content="https://gdoop.us/careers/assets/preview.jpg">
    <!-- Add your preview image URL -->
    <meta property="og:url" content="https://www.gdoop.us/careers">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Gdoop Careers">

    <!-- Schema Markup (Structured Data for Search Engines) -->
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": "Gdoop Careers",
            "url": "https://www.gdoop.us/careers",
            "description": "careers",
            "image": "https://gdoop.us/assets/preview.jpg",
            "sameAs": [
                "https://www.facebook.com/yourpage",
                "https://twitter.com/yourtwitterhandle",
                "https://www.linkedin.com/company/gdoop"
            ]
        }
    </script>

    <!-- Robots Meta (Indexing Instructions for Search Engines) -->
    <meta name="robots" content="index, follow">

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="./assets/fonts.css">

</head>

<body>
    <header>
        <div class="item">
            <a href="gdoop.us/careers"><img src="./assets/preview.png" class="logo" alt=""></a>
        </div>
        <div class="item">
            <a href="https://gdoop.us"><img src="./assets/home.svg" class="btn-0" alt=""></a>
            <a href="https://wa.me/+94765395434"><img src="./assets/call.svg" class="btn-0" alt=""></a>
        </div>
    </header>

    <section>
        <div class="container">
            <h1>🚀Join Gdoop as a Freelancer!</h1>
            <p>Are you a skilled freelancer looking for exciting opportunities? Grow your freelance career with us. Whether you're into design, writing, programming, or marketing – we welcome passionate individuals from all fields!</p>
            <br>
            <p>✅ Work from anywhere.</p>
            <p>✅ Get connected with real clients.</p>
            <p>✅ Flexible hours, fair pay.</p>
            <p>✅ Grow your skills and earn.</p>
            <br>
            <p>Register today and become part of a growing freelancer community!</p>
            <p>careers@gdoop.us | +94765395434</p>
        </div>
    </section>

    <form class="form-1" enctype="multipart/form-data">
        <div class="item">
            <label for="positions">Interested Position</label>
            <select name="positions" id="positions"></select>
        </div>
        <div class="item">
            <label for="email">Email Address</label>
            <input name="email" type="text" id="email">
        </div>
        <div class="item">
            <label for="cv">Upload CV</label>
            <input name="file" type="file" id="cv">
        </div>
        <div class="item">
            <label for="working-time">Working Time</label>
            <select name="working-time" id="working-time">
                <option value="anytime">Anytime</option>
                <option value="day">Day (8:00AM - 5:00PM)</option>
                <option value="night">Night (8:00PM - 5:00AM)</option>
            </select>
        </div>
        <div class="item bank" style="display: none;">
            <p>Bank Account Details</p>
            <div>
                <input type="text" id="bank-name" name="bank-name" placeholder="Account Name">
                <input type="text" id="bank-number" name="bank-number" placeholder="Account Number">
                <input type="text" id="bank-branch" name="bank-branch" placeholder="Account Branch">
            </div>
        </div>
        <div class="item">
            <a target="_blank" href="terms">Terms & conditions</a>
            <input class="btn-1" name="submit" type="submit" value="Submit">
            <br>
            <p id="responseMessage" class="mt-3"></p>
        </div>

        <footer>
            <p>&copy; 2022 - 2025 Gdoop. All Rights Reserved.</p>
            <div class="sub-item">
                <a href="#">Policy</a> |
                <a href="#">Terms</a>
            </div>
        </footer>
    </form>
</body>

</html>